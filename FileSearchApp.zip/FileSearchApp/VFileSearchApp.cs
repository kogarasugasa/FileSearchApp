﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace FileSearchApp
{
    public partial class AppView : Form
    {
        private string _title = "Search";
        private ListViewDoubleBuff _listView = new ListViewDoubleBuff();
        private Button _optionBtn = new Button();
        private CheckBox _aliasCheckBox = new CheckBox();
        private Button _getClipBtn = new Button();
        private Button _runSearchBtn = new Button();
        private TextBox _searchWordsTxtbox = new TextBox();
        private VMFileSearchApp _viewModelFileSearchApp;
        private VMListView _viewModelListView;
        private MSettings _modelSettings;
        private MTagManager _modelTag;
        private Func<List<ToolStripMenuItem>> _createOptionMenuItems;
        private Func<List<ToolStripMenuItem>> _createListViewMenuItems;
        private MHistorySearcher _modelHistory = new MHistorySearcher();
        VMDisabledHistory _viewModelDisHis;
        private MAliasManager _modelAlias;
        private MMessageReceiver _msgReceiver = new MMessageReceiver(true);
        public AppView(string[] args)
        {
            _modelSettings = new MSettings();
            _modelAlias = new MAliasManager(_modelSettings.GetAlias);
            _modelTag = new MTagManager(_modelSettings.GetFileNameTags());
            _modelTag.GetAllTags = _modelSettings.GetTagMS;
            _viewModelListView = new VMListView(_modelSettings.GetTagMS, _modelSettings.GetColumnWidth());
            _viewModelListView.DisplayFileInfos.GetAliasMethod = _modelAlias.GetAlias;

            _modelHistory = new MHistorySearcher();
            _modelHistory.GetAlias = _modelAlias.GetAlias;
            _modelHistory.GetExcludeDirectory = _modelSettings.GetExcludeDirectory;
            _modelHistory.Read(_modelSettings.GetSearchResultHistory);
            _modelHistory.RunActionWhenFileFound.Add((val) =>
            {
                _viewModelListView.DisplayFileInfos.TryAddNotDuplicate(val);
            });
            
            var mTagSercher = new MTagSearcher();
            mTagSercher.GetAllTags = _modelSettings.GetTagMS;
            mTagSercher.GetTags = _modelTag.GetTags;
            mTagSercher.GetNames = _modelTag.GetNames;
            mTagSercher.GetSource = _modelHistory.GetResultAndRunSearch;
            mTagSercher.GetExFileInfos = _modelHistory.GetExFileInfos;
            mTagSercher.RunActionWhenFileFound.Add((val) =>
            {
                _viewModelListView.DisplayFileInfos.TryAddNotDuplicate(val);
            });
            
            var mFileSearchApp = new MWindowsSearcher();
            mFileSearchApp.GetIncludeDirectorys = _modelSettings.GetSearchDirectorys;
            mFileSearchApp.GetExcludeDirectorys = _modelSettings.GetExcludeDirectory;
            mFileSearchApp.ExtraKeyWordsGetters.Add(list =>
            {
                var matchNames = new List<string>();
                foreach (var val in list)
                {
                    matchNames.AddRange(_modelAlias.GetNamesFuzzy(val));
                }
                return matchNames;
            });
            mFileSearchApp.RunActionWhenFileFound.Add((val) =>
            {
                _viewModelListView.DisplayFileInfos.TryAddNotDuplicate(val);
                _modelHistory.AddToBuffer(val.FilePath);
            });
            _viewModelFileSearchApp = new VMFileSearchApp(_viewModelListView, new SizePosition(_modelSettings.GetWindowSize()));
            _viewModelFileSearchApp.Searcher.Add(_modelHistory, () => _viewModelFileSearchApp.SearchWords.Length != 0);
            _viewModelFileSearchApp.Searcher.Add(mFileSearchApp, () => _viewModelFileSearchApp.SearchWords.Length != 0);
            _viewModelFileSearchApp.Searcher.Add(mTagSercher, () => _viewModelFileSearchApp.SearchWords.Length == 0);
            _createOptionMenuItems = () =>
            {
                var fac = new MFactoryToolStripMenuItem();
                var menuItems = fac.CreateOptionMenuItems(
                    _modelSettings.OpenDirectorySettings,
                    _modelSettings.OpenTagSettings,
                    _modelSettings.OpenExcludeDirectorySettings,
                    _viewModelListView.ApplyFilter,
                    _modelSettings.GetTagMS,
                    _modelTag.GetTags,
                    _viewModelListView.ExportCsv,
                    ShowHistoryMaintenance
                    );
                return menuItems;
            };
            _createListViewMenuItems = () =>
            {
                var fac = new MFactoryToolStripMenuItem();
                var menuItems = fac.CreateListViewMenuItems(
                    _viewModelListView.OpenSelectionPathAsync,
                    _modelSettings.GetTagMS,
                    _viewModelListView.GetExFileInfoAsync,
                    _modelTag.Add,
                    _modelTag.Remove,
                    _modelAlias.Add
                    );
                return menuItems;
            };
            //
            var hiswinlv = new VMListView(
                _viewModelListView.ListViewColumnHeaders.Select(val => val.Width).ToList(),
                _viewModelListView.DisplayFileInfos
            );
            _viewModelDisHis = new VMDisabledHistory(_modelHistory.Remove, hiswinlv);
            var hiswin = new MWindowsSearcher();
            hiswin.GetIncludeDirectorys = _modelSettings.GetSearchDirectorys;
            hiswin.GetExcludeDirectorys = _modelSettings.GetExcludeDirectory;
            hiswin.RunActionWhenFileFound.Add(info =>
            {
                _viewModelDisHis.SearchResult.Add(info);
                _modelHistory.AddToBuffer(info.FilePath);
            });
            _viewModelDisHis.Searcher.Add(hiswin, () => _viewModelDisHis.SearchWords.Length != 0);
            //
            this.Enabled = false;
            //引数付きの処理
            if (args.Count() != 0){
                Task.Run(() => ShowAddTagAliasForm(args[0]));
            }
            InitializeComponent();
            InitializeEventSet();
            var appPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
            var appTmpPath = Path.GetTempFileName();
            File.Copy(appPath, appTmpPath, true);
            this.Icon = System.Drawing.Icon.ExtractAssociatedIcon(appTmpPath);
        }
        ~AppView()
        {
            this.Icon.Dispose();
        }
        private void Form_FormClosed(object sender, EventArgs e)
        {
            _modelTag.Save(_modelSettings.WriteFileNameTag);
            _modelHistory.Save(_modelSettings.WriteSearchResultHistory);
            _modelAlias.Save(_modelSettings.WriteAlias);
            _modelSettings.TryCreateSearchDirectorys();
            _modelSettings.TryCreateTagMS();
            _modelSettings.TryCreateExcludeDirectory();
            _modelSettings.WriteColumnWidth(_viewModelListView.ListViewColumnHeaders.Select(val => val.Width).ToList());
            _modelSettings.WriteWindowSize(_viewModelFileSearchApp.WindowProperty.ToList());
        }
        private void InitializeComponent()
        {
            this.Text = _title;
            //オプションボタンメニュー
            this.ContextMenuStrip = new ContextMenuStrip();
            _viewModelFileSearchApp.OptionMenuItems.ForEach(val => this.ContextMenuStrip.Items.Add(val));
            //オプションボタン
            this.Controls.Add(_optionBtn);
            _optionBtn.Text = "三";
            _optionBtn.Top = 9;
            _optionBtn.Left = 10;
            _optionBtn.Height = 21;
            _optionBtn.Width = 30;
            //クリップボード貼り付けボタン
            this.Controls.Add(_getClipBtn);
            _getClipBtn.Text = "Clip";
            _getClipBtn.Top = 9;
            _getClipBtn.Left = _optionBtn.Left + _optionBtn.Width;
            _getClipBtn.Height = 21;
            _getClipBtn.Width = 50;
            //実行ボタン
            this.Controls.Add(_runSearchBtn);
            _runSearchBtn.Text = "Run";
            _runSearchBtn.Top = 9;
            _runSearchBtn.Left = _getClipBtn.Left + _getClipBtn.Width;
            _runSearchBtn.Height = 21;
            _runSearchBtn.Width = 40;
            //別名チェックボックス
            this.Controls.Add(_aliasCheckBox);
            _aliasCheckBox.Text = "Alias";
            _aliasCheckBox.Top = 9;
            _aliasCheckBox.Left = 5 + _runSearchBtn.Left + _runSearchBtn.Width;
            _aliasCheckBox.Width = 50;
            _aliasCheckBox.Checked = _viewModelListView.AliasEnabled;
            //入力文字列テキストボックス
            this.Controls.Add(_searchWordsTxtbox);
            _searchWordsTxtbox.Top = 10;
            _searchWordsTxtbox.Left = _aliasCheckBox.Left + _aliasCheckBox.Width;
            _searchWordsTxtbox.Width = this.Width - _searchWordsTxtbox.Left - 26;
            //リストビュー
            this.Controls.Add(_listView);
            _listView.Top = _searchWordsTxtbox.Top + _searchWordsTxtbox.Height + 5;
            _listView.Left = 10;
            _listView.Height = this.Height - _listView.Top - 50;
            _listView.Width = this.Width - 36;
            _listView.VirtualMode = true;
            _listView.MultiSelect = false;
            _listView.AllowColumnReorder = true;
            _listView.FullRowSelect = true;
            _listView.Scrollable = true;
            _listView.GridLines = true;
            _listView.HideSelection = false;
            _listView.Sorting = SortOrder.Ascending;
            _listView.View = View.Details;
            _listView.Columns.AddRange(_viewModelListView.ListViewColumnHeaders);
            _listView.ContextMenuStrip = new ContextMenuStrip();
            _viewModelListView.ListViewMenuItems.ForEach(val => _listView.ContextMenuStrip.Items.Add(val));
        }
    }
    public class ListViewDoubleBuff : System.Windows.Forms.ListView
    {
        public ListViewDoubleBuff()
        {
            this.DoubleBuffered = true;
        }
    }
}
