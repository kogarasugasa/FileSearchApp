using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Data.OleDb;

namespace FileSearchApp
{
    public class MWindowsSearcher : ISearcher
    {
        public MWindowsSearcher()
        {
            this.GetIncludeDirectorys = () => new List<string>();
            this.GetExcludeDirectorys = () => new List<string>();
            this.RunActionWhenFileFound = new List<Action<ExFileInfo>>();
            this.ExtraKeyWordsGetters = new List<Func<List<string>, List<string>>>();
            this.ExcludeDirectoryPath = new SortedSet<string>();
            this.SearchWords = new List<string>();
        }
        public Task StartSearchAsync(CancellationToken ct)
        {
            var tsk = Task.Run(() =>
            {
                foreach (var info in GetResultAndRunSearch(this.GetIncludeDirectorys(), this.SearchWords, ct))
                {
                    foreach (var method in this.RunActionWhenFileFound)
                    {
                        method(info);
                    }
                }
            });
            return tsk;
        }
        public IEnumerable<ExFileInfo> GetResultAndRunSearch(List<string> DirPaths, List<string> SearchWords, CancellationToken cancellationToken)
        {
            if (SearchWords.Count == 1)
            {
                if (SearchWords[0].Length == 0)
                {
                    yield break;
                }
            }
            foreach (var val in this.GetExcludeDirectorys())
            {
                this.ExcludeDirectoryPath.Add(val);
            }
            //Windows インデックス検索実行
            var findFiles = new ConcurrentQueue<ExFileInfo>();
            var searchTask = Task.Run(() =>
            {
                MultiThreadSearch(DirPaths, SearchWords, findFiles, cancellationToken);
            });
            int findFilesIndex = 0;
            while (true)
            {
                while (true)
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        yield break;
                    }
                    //値が追加されたらループを抜ける
                    if (findFiles.Count >= findFilesIndex + 1)
                    {
                        break;
                    }
                    //完了してたらループを抜ける
                    if (searchTask.IsCompleted)
                    {
                        break;
                    }
                    Task.Delay(200).Wait();
                }
                if (searchTask.IsCompleted & findFiles.Count < findFilesIndex + 1)
                {
                    break;
                }
                if (findFiles.Count == 0)
                {
                    continue;
                }
                var fileInfo = findFiles.ElementAt(findFilesIndex);
                if (IsExcludeDirectory(fileInfo.FilePath)){
                    findFilesIndex++;
                    continue;
                }
                yield return fileInfo;
                findFilesIndex++;
            }
        }
        public void MultiThreadSearch(List<string> DirPaths, List<string> SearchWords, ConcurrentQueue<ExFileInfo> findFilesResult, CancellationToken cancellationToken)
        {
            if (findFilesResult == null)
            {
                return;
            }
            if (DirPaths == null)
            {
                return;
            }
            var dirPathQueue = new Queue<string>(DirPaths.ToArray());
            var currentExecutingDrive = new ConcurrentDictionary<string, int>();
            List<Task> searchTasksResult = new List<Task>();
            while (true)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    break;
                }

                //実行待ちが無くなったら終了
                if (dirPathQueue.Count == 0)
                {
                    break;
                }
                //同時実行数が閾値を超える場合スキップ
                if (currentExecutingDrive.Count > 2)
                {
                    Task.Delay(1000).Wait();
                    continue;
                }
                //ディレクトリ取得
                string dirPath = dirPathQueue.Dequeue();
                //現在のドライブが実行中であればスキップ
                string drive = GetDriveGroupName(dirPath);
                if (currentExecutingDrive.ContainsKey(drive))
                {
                    dirPathQueue.Enqueue(dirPath);
                    continue;
                }
                //検索実行
                currentExecutingDrive.TryAdd(drive, 1);
                var currentTask = Task.Run(() => SwitchSearch(dirPath, SearchWords, findFilesResult, currentExecutingDrive, cancellationToken));
                searchTasksResult.Add(currentTask);
                continue;
            };
            Task.WaitAll(searchTasksResult.ToArray());
        }
        private void SwitchSearch(string DirPath,
            List<string> SearchWords,
            ConcurrentQueue<ExFileInfo> ResultFileInfos,
            ConcurrentDictionary<string, int> CurrentTasks,
            CancellationToken cancellationToken
            )
        {
            string query = CreateWindowsSearchQuery(DirPath, SearchWords);
            bool indexSearchErr = false;
            try
            {
                foreach (var info in WindowsSearch(query, cancellationToken))
                {
                    ResultFileInfos.Enqueue(info);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                indexSearchErr = true;
            }
            if (indexSearchErr)
            {
                foreach (var info in WhereSearch(DirPath, SearchWords, cancellationToken))
                {
                    ResultFileInfos.Enqueue(info);
                }
            }
            string drive = GetDriveGroupName(DirPath);
            int noUse;
            CurrentTasks.TryRemove(drive, out noUse);
            return;
        }
        public IEnumerable<ExFileInfo> WhereSearch(string dirPath, List<string> SearchWords, CancellationToken cancellationToken)
        {
            var searchWords = SearchWords.Where((str) => str != string.Empty);
            if (searchWords.Count() == 0)
            {
                yield break;
            }
            //「*」を先頭と末尾に付加し、「*」または「?」が連続した場合は1つにまとめる
            List<string> checkedSearchWords = new List<string>();
            foreach (string word in searchWords)
            {
                string word2 = word.Insert(0, "*") + "*";
                string beforeChar = string.Empty;
                string chars = string.Empty;
                for (int i = 0; i <= word2.Length - 1; i++)
                {
                    string oneChar = word2.Substring(i, 1);
                    if (oneChar == "*" & oneChar == beforeChar) { continue; }
                    chars += oneChar;
                    beforeChar = oneChar;
                }
                checkedSearchWords.Add(chars);
            }
            //コマンドプロンプトの where コマンドを使用してファイルを検索する
            string searchWordsParams = string.Join("\" \"", checkedSearchWords);
            ProcessStartInfo psInfo = new ProcessStartInfo
            {
                FileName = System.Environment.GetEnvironmentVariable("ComSpec"),
                Arguments = " /c \"where /t /r \"" + dirPath.Replace("/", "\\") + "\" \"" + searchWordsParams + "\"\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };
            //検索実行
            foreach (var val in WhereSearch(psInfo, cancellationToken))
            {
                yield return val;
            }
        }
        private IEnumerable<ExFileInfo> WhereSearch(ProcessStartInfo info, CancellationToken cancellationToken)
        {
            object buf;
            using (var process = Process.Start(info))
            {
                var task = Task.Run(() =>
                {
                    while (true)
                    {
                        if (!cancellationToken.IsCancellationRequested)
                        {
                            Task.Delay(100).Wait();
                            continue;
                        }
                        int pid = process.Id;
                        string taskkill = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "taskkill.exe");
                        using (var procKiller = new System.Diagnostics.Process())
                        {
                            procKiller.StartInfo.FileName = taskkill;
                            procKiller.StartInfo.Arguments = string.Format("/PID {0} /T /F", pid);
                            procKiller.StartInfo.CreateNoWindow = true;
                            procKiller.StartInfo.UseShellExecute = false;
                            procKiller.Start();
                            procKiller.WaitForExit();
                        }
                        break;
                    }
                });
                while (true)
                {
                    buf = process.StandardOutput.ReadLine();
                    if (buf == null & process.HasExited)
                    {
                        break;
                    }
                    if (buf == null)
                    {
                        continue;
                    }
                    string readLineResult = (string)buf;
                    yield return WhereResultToExFileInfo(readLineResult);
                }
            }
        }
        private ExFileInfo WhereResultToExFileInfo(string result)
        {
            string[] strAry = result.Trim(' ').Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            int parseCount = 0;

            int fileSize = 0;
            if (int.TryParse(strAry[0], out fileSize))
            {
                parseCount++;
            }
            DateTime lastWriteDate = DateTime.MinValue;
            if (DateTime.TryParse(strAry[1], out lastWriteDate))
            {
                parseCount++;
            }
            TimeSpan lastWriteSpan = TimeSpan.MinValue;
            if (TimeSpan.TryParse(strAry[2], out lastWriteSpan))
            {
                parseCount++;
            }
            if (parseCount != 3)
            {
                return new ExFileInfo
                {
                    FilePath = result
                };
            }
            string filePath = result.Substring(39);
            if (filePath.Replace(" ", "").Replace("　", "").Length != 0)
            {
                filePath = filePath.TrimStart();
            }
            return new ExFileInfo
            {
                FilePath = filePath,
                LastWriteTime = lastWriteDate + lastWriteSpan,
                Size = fileSize
            };
        }
        private IEnumerable<ExFileInfo> WindowsSearch(string query, CancellationToken cancellationToken)
        {
            var connectionString = "Provider=Search.CollatorDSO;Extended Properties='Application=Windows';";
            if (!query.ToLower().StartsWith("select "))
            {
                throw new Exception("クエリの先頭の文字が「select 」ではありません");
            }
            var checkQuery = query.ToLower().Replace("select ", "select top 1 ");
            using (var conn = new OleDbConnection(connectionString))
            using (var cmd = new OleDbCommand(checkQuery, conn))
            {
                conn.Open();
                cmd.ExecuteReader();
            }
            using (var conn = new OleDbConnection(connectionString))
            using (var cmd = new OleDbCommand(query, conn))
            {
                try
                {
                    conn.Open();
                    var results = cmd.ExecuteReader();
                    while (results.Read())
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            yield break;
                        }
                        var fileName = results.GetString(0);
                        Decimal fileSize = 0;
                        if (!results.IsDBNull(1))
                        {
                            fileSize = results.GetDecimal(1);
                        }
                        var filePath = results.GetString(0);
                        filePath = filePath.Replace(@"C:\ユーザー", @"C:\users");
                        if (filePath.Length >= @"C:\users".Length + 1)
                        {
                            var userName = filePath.Substring(@"C:\users".Length + 1);
                            if (userName.Contains('\\'))
                            {
                                userName = userName.Substring(0, userName.IndexOf('\\'));
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\ビデオ", @"C:\users\" + userName + @"\Videos");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\ミュージック", @"C:\users\" + userName + @"\Music");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\リンク", @"C:\users\" + userName + @"\Links");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\検索", @"C:\users\" + userName + @"\Searches");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\保存したゲーム", @"C:\users\" + userName + @"\Saved Games");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\アドレス帳", @"C:\users\" + userName + @"\Contacts");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\お気に入り", @"C:\users\" + userName + @"\Favorites");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\デスクトップ", @"C:\users\" + userName + @"\Desktop");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\ピクチャ", @"C:\users\" + userName + @"\Pictures");
                                filePath = filePath.Replace(@"C:\users\" + userName + @"\ダウンロード", @"C:\users\" + userName + @"\Downloads");
                            }
                        }
                        var fileInfo = new ExFileInfo
                        {
                            FilePath = filePath,
                            Size = fileSize
                        };
                        yield return fileInfo;
                    }
                    results.Close();
                    conn.Close();
                }
                finally
                {
                    cmd.Dispose();
                    conn.Dispose();
                }
            }
        }
        public string CreateWindowsSearchQuery(string DirectoryPath, List<string> SearchWords)
        {
            string networkPath;
            string computerName = "";
            string dirPath;
            var searchWords = new List<string>();
            foreach (var word in SearchWords)
            {
                var searchWord = string.Empty;
                foreach(var cha in word)
                {
                    if (cha == '['){
                        searchWord += "[[]";
                    }else if (cha == ']'){
                        searchWord += "[]]";
                    }else{
                        searchWord += cha;
                    }
                }
                searchWords.Add(searchWord);
            }
            if (TryConvertToNetworkPath(DirectoryPath, out networkPath)){
                dirPath = networkPath
                    .Replace("\\", "/")
                    .TrimEnd('/');
            }else{
                dirPath = DirectoryPath
                    .Replace("\\", "/")
                    .TrimEnd('/');
            }
            if (dirPath.StartsWith("/")){
                computerName = dirPath.Substring(2, dirPath.IndexOf("/", 2) - 2) + ".";
            }
            string whereSection = "System.ItemName LIKE '%" + 
                string.Join("%' or System.ItemName LIKE '%", searchWords)
                .Replace("*", "%")
                .Replace("?", "_") + "%'";
            //クエリ作成
            var query = "SELECT System.ItemPathDisplay, System.Size ";
            query += "FROM " + computerName + "SystemIndex ";
            query += "WHERE Scope = 'file:" + dirPath + "' ";
            query += "AND (" + whereSection + ")";
            return query;
        }
        public string GetDriveGroupName(string DirectoryPath)
        {
            string dirPath;
            if (TryConvertToNetworkPath(DirectoryPath, out dirPath))
            {
                return "Network";
            }
            else
            {
                return DirectoryPath.Substring(0, 1).ToUpper();
            }
        }
        public bool TryConvertToNetworkPath(string DirectoryPath, out string NetworkPath)
        {
            //フォルダパス変換
            if (!DirectoryPath.StartsWith("\\"))
            {
                var driveInfo = new DriveInfo(DirectoryPath.Substring(0, 1));
                if (driveInfo.DriveType == DriveType.Network)
                {
                    NetworkPath = MyNativeMethod.Function.Drive.GetUniversalName(driveInfo.Name);
                    return true;
                }
            }
            NetworkPath = "";
            return false;
        }
        public void SetKeyWords(List<string> pSearchWords)
        {
            var key_words = new List<string>(pSearchWords);
            foreach (var getter in this.ExtraKeyWordsGetters)
            {
                key_words.AddRange(getter(pSearchWords));
            }
            key_words.AddRange(pSearchWords);
            this.SearchWords = key_words.Distinct().ToList();
        }
        public bool IsExcludeDirectory(string pDirPath)
        {
            foreach (var val in this.ExcludeDirectoryPath)
            {
                var ecldPath = val;
                if (pDirPath.ToLower().StartsWith(ecldPath.ToLower())){
                    return true;
                }
            }
            return false;
        }
        public List<Func<List<string>, List<string>>> ExtraKeyWordsGetters { get; private set; }
        public Func<List<string>> GetIncludeDirectorys { get; set; }
        public Func<List<string>> GetExcludeDirectorys { get; set; }
        private SortedSet<string> ExcludeDirectoryPath { get; set; }
        public List<string> SearchWords { get; set; }
        public List<Action<ExFileInfo>> RunActionWhenFileFound { get; private set; }
    }
}