using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Windows.Forms;

namespace FileSearchApp
{
    public class VMFileSearchApp
    {
        object _lock = new object();
        VMListView _viewModelListView;
        CancellationTokenSource _cts = new CancellationTokenSource();
        public VMFileSearchApp(VMListView pViewModelListView, SizePosition pSizePosition)
        {
            _viewModelListView = pViewModelListView;
            this.SearchWords = string.Empty;
            this.OptionMenuItems = new List<ToolStripMenuItem>();
            this.WindowProperty = pSizePosition;
            this.CheckWindowProperty(true);
            this.Searcher = new Dictionary<ISearcher, Func<bool>>();
        }
        ~VMFileSearchApp()
        {
            _cts.Cancel();
            _cts.Dispose();
            foreach (var val in this.OptionMenuItems)
            {
                if (val != null){
                    val.Dispose();
                }
            }
        }
        public async Task StartSearch()
        {
            lock (_lock)
            {
                if (this.IsSearching){
                    return;
                }
                this.IsSearching = true;
                if (this.OptionMenuItems.Where(val => val.Checked).Count() != 0){
                    MessageBox.Show("フィルタが適用されたまま検索を実行します");
                }
            }
            _cts.Dispose();
            _cts = new CancellationTokenSource();
            _viewModelListView.Clear();

            //Runボタンがクルクルし始める
            var anime = WaitingAnimationAsync(_cts.Token);
            //検索中にリストを更新するタイマーを開始
            _viewModelListView.StartUpdateTimer();
            //検索を開始する
            var tasks = new List<Task>();
            foreach (var val in this.Searcher)
            {
                if (val.Value())
                {
                    val.Key.SetKeyWords(this.SearchWords.Split(':').ToList());
                    tasks.Add(val.Key.StartSearchAsync(_cts.Token));
                }
            }
            await Task.WhenAll(tasks);
            _cts.Cancel();
            _viewModelListView.StopUpdateTimer();
            lock (_lock)
            {
                this.IsSearching = false;
            }
        }
        public void CancelSearch()
        {
            _cts.Cancel();
        }
        private async Task WaitingAnimationAsync(CancellationToken cancellationToken)
        //検索中であることがわかる検索アニメーションを開始する
        {
            await Task.Run(() =>
            {
                try
                {
                    string[] strs = { "／", "─", "＼", "｜", };
                    int i = 0;
                    while (!cancellationToken.IsCancellationRequested)
                    {
                        RunCaption = strs[i];
                        Task.Delay(50, cancellationToken).Wait();
                        i++;
                        if (i > 3)
                        {
                            i = 0;
                        }
                    }
                }
                finally
                {
                    RunCaption = "Run";
                }
            });
        }
        public string GetClip()
        {
            if (Clipboard.ContainsText())
            {
                return Clipboard.GetText();
            }
            else
            {
                return string.Empty;
            }
        }
        public bool CheckWindowProperty(bool pPropertyChange = false)
        {
            bool changed = false;
            var size = new SizePosition(this.WindowProperty.ToList());
            if (size.Top + 200 > Screen.PrimaryScreen.Bounds.Height)
            {
                size.Top = Screen.PrimaryScreen.Bounds.Height / 2;
                changed = true;
            }
            if (size.Left + 200 > Screen.PrimaryScreen.Bounds.Width)
            {
                size.Left = Screen.PrimaryScreen.Bounds.Width / 2;
                changed = true;
            }
            if (size.Width < 500)
            {
                size.Width = 500;
                changed = true;
            }
            if (size.Height < 300)
            {
                size.Height = 300;
                changed = true;
            }
            if (pPropertyChange)
            {
                this.WindowProperty = size;
            }
            if (changed)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        // ============================================================
        // = 説明：プロパティ
        // ============================================================
        public string SearchWords { get; set; }
        public bool IsSearching { get; private set; }
        private string _runCaption = "Run";
        public string RunCaption
        {
            get { return _runCaption; }
            private set
            {
                _runCaption = value;
                var args = new ViewModelRunCaptionChangedEventArgs(_runCaption);
                ViewModeRunCaptionChanged.Invoke(this, args);
            }
        }
        public List<ToolStripMenuItem> OptionMenuItems { get; set; } //set するとき中身を全てDisposeして！！
        public SizePosition WindowProperty { get; set; }
        public Dictionary<ISearcher, Func<bool>> Searcher { get; private set; }
        // ============================================================
        // = 説明：イベント
        // ============================================================
        public event EventHandler<ViewModelRunCaptionChangedEventArgs> ViewModeRunCaptionChanged = delegate { };
    }
}