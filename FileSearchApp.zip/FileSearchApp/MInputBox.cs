using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileSearchApp
{
    public static class MInputBox
    {
        public static string GetText(string pText)
        {
            var vm = new VMInputBox(pText);
            Task.Run(() => Application.Run(new VInputBox(vm))).Wait();
            return vm.Text;
        }
    }
    public class VInputBox : Form
    {
        TextBox _textBox = new TextBox(){Top = 10, Left = 10, Width = 210};
        VMInputBox _viewModelInputBox;
        
        public VInputBox(VMInputBox pVMInputBox)
        {
            _viewModelInputBox = pVMInputBox;
            _textBox.Text = pVMInputBox.Text;
            _textBox.Width = this.Width - 36;
            this.Text = "Input Text";
            this.Width = Math.Max(pVMInputBox.Text.Length * 10 + 40, 300);
            this.Height = 78;
            this.Controls.Add(_textBox);
            this.Load += new EventHandler((s, e) =>
            {
                this.Top = Cursor.Position.Y;
                this.Left = Cursor.Position.X;
            });
            this.Shown += new EventHandler((s, e) =>
            {
                this.TopMost = true;
                Task.Delay(100).Wait(); //ちょい待つとフォーカスを取得できることが多い
                this.Focus();
                _textBox.Focus();
            });
            _textBox.KeyPress += new KeyPressEventHandler((s, e) =>
            {
                if ( e.KeyChar != (char)Keys.Enter ){
                    return;
                }
                _viewModelInputBox.Text = _textBox.Text;
                this.Close();
            });
        }
    }
    public class VMInputBox
    {
        public VMInputBox(string pText){this.Text = pText;}
        public string Text = string.Empty;
    }
}