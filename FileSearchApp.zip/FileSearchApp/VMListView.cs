using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Concurrent;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;


namespace FileSearchApp
{
    public class VMListView
    {
        private SortOrder _previousSortOrder = SortOrder.None;
        private int _previousSortColumn = 0;
        private object _lock = new object();
        private System.Timers.Timer _displayUpdateTimer = new System.Timers.Timer();
        public VMListView(Func<List<string>> pGetTagMsMethod, List<int> pColumnWidths)
        {
            _displayUpdateTimer.Elapsed += new System.Timers.ElapsedEventHandler((s, e) => DisplayUpdate());
            _displayUpdateTimer.Interval = 500;
            this.DisplayFileInfos = new MExFileInfoCollection();
            this.SelectionIndex = -1;
            this.SelectionItem = new ListViewItem();
            this.ListViewMenuItems = new List<ToolStripMenuItem>();
            this.ListViewCursor = Cursors.Default;
            this.ListViewColumnHeaders = CreateListViewColumnHeader(pColumnWidths);
            this.AliasEnabled = true;
        }
        public VMListView(List<int> pColumnWidths, MExFileInfoCollection pCollection)
        {
            this.DisplayFileInfos = pCollection;
            _displayUpdateTimer.Elapsed += new System.Timers.ElapsedEventHandler((s, e) => DisplayUpdate());
            _displayUpdateTimer.Interval = 500;
            this.SelectedIndices = new SortedSet<int>();
            this.SelectionIndex = -1;
            this.SelectionItem = new ListViewItem();
            this.ListViewMenuItems = new List<ToolStripMenuItem>();
            this.ListViewCursor = Cursors.Default;
            this.ListViewColumnHeaders = CreateListViewColumnHeader(pColumnWidths);
            this.AliasEnabled = true;
        }
        ~VMListView()
        {
            foreach (var val in this.ListViewMenuItems)
            {
                if (val != null){
                    val.Dispose();
                }
            }
            foreach (var val in this.ListViewColumnHeaders)
            {
                if (val != null){
                    if (val.ImageList != null){
                        val.ImageList.Dispose();
                    }
                }
            }
            if (this.SelectionItem.ImageList != null){
                this.SelectionItem.ImageList.Dispose();
            }
            _displayUpdateTimer.Dispose();
        }
        public ListViewItem ConvToListViewItem(ExFileInfo info, int seq)
        {
            decimal size;
            //Where コマンドで出力されたサイズはオーバーフローしている値が存在するため
            //  オーバーフロー分を計算する 計算したとしても4GB以上は判別できない
            if (info.Size < 0){
                size = info.Size + (decimal)2147483648 * 2; //2GB
            }else{
                size = info.Size;
            }
            string str = string.Empty;
            if (size > (decimal)Math.Pow(1024, 5) * 9){
                str = (size / (decimal)Math.Pow(1024, 5)).ToString("#") + "PB";
            }else if (size > (decimal)Math.Pow(1024, 4) * 9){
                str = (size / (decimal)Math.Pow(1024, 4)).ToString("#") + "TB";
            }else if (size > (decimal)Math.Pow(1024, 3) * 9){
                str = (size / (decimal)Math.Pow(1024, 3)).ToString("#") + "GB";
            }else if (size > (decimal)Math.Pow(1024, 2) * 9){
                str = (size / (decimal)Math.Pow(1024, 2)).ToString("#") + "MB";
            }else if (size > (decimal)1024 * 9){
                str = (size / (decimal)1024).ToString("#") + "KB";
            }else{
                str = size.ToString("0") + " B";
            }

            //順番大事！
            var item = new ListViewItem("");
            item.SubItems.Add(seq.ToString());
            if (this.AliasEnabled & info.Alias != string.Empty){
                item.SubItems.Add(info.Alias);
            }else{
                item.SubItems.Add(info.FileName());
            }
            item.SubItems.Add(info.Extension());
            item.SubItems.Add(str);
            item.SubItems.Add(info.FilePath);
            return item;
        }
        public void Clear()
        {
            this.VirtualListSize = 0;
            this.SelectionIndex = -1;
            this.SelectedIndices.Clear();
            this.SelectionItem = new ListViewItem();
            this.DisplayFileInfos.Clear();
        }
        public ColumnHeader[] CreateListViewColumnHeader(List<int> pColumnWidths)
        {
            var header = new ColumnHeader[]
            {
                new ColumnHeader{Text = "", Width = 0},
                new ColumnHeader{Text = "Num", Width = 50, TextAlign = HorizontalAlignment.Right},
                new ColumnHeader{Text = "FileName", Width = 100},
                new ColumnHeader{Text = "Extension", Width = 70},
                new ColumnHeader{Text = "Size", Width = 60, TextAlign = HorizontalAlignment.Right},
                new ColumnHeader{Text = "Path", Width = 100},
            };
            if (pColumnWidths.Count == 0){
                return header;
            }
            int num = pColumnWidths.Count;
            num = Math.Min(header.Count(), num);
            for (int i = 0; i < num; i++)
            {
                header[i].Width = pColumnWidths[i];
            }
            return header;
        }

        public void ChangeCursor(Cursor pCursor)
        {
            this.ListViewCursor = pCursor;
        }
        public async Task OpenSelectionPathAsync()
        {
            var info = this.DisplayFileInfos.ElementAt(this.SelectionIndex);
            string filePath = info.FilePath;
            bool exists = await Task<bool>.Run(() => File.Exists(filePath) | Directory.Exists(filePath));
            if (!exists){
                info.Invalided = true;
                var alert = new AlertEventArgs(filePath);
                ViewModelOpenFileAlert.Invoke(this, alert);
                return;
            }
            try
            {
                this.ListViewCursor = Cursors.AppStarting;
                string cmdStr = "start \"\" \"explorer.exe\" /select,\"" + filePath + "\"";
                var psInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = " /c \"" + cmdStr + "\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                using (var pro = new Process())
                {
                    pro.StartInfo = psInfo;
                    await Task.Run(() => pro.Start());
                }
            }
            catch (System.ComponentModel.Win32Exception)
            {
                MessageBox.Show("関連付けのされていないファイルは開けません");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            await Task.Delay(1000);
            this.ListViewCursor = Cursors.Default;
        }
        public async Task OpenSelectionItemAsync()
        {
            var info = this.DisplayFileInfos.ElementAt(this.SelectionIndex);
            var filePath = info.FilePath;
            bool exists = await Task<bool>.Run(() => File.Exists(filePath) | Directory.Exists(filePath));
            if (!exists)
            {
                info.Invalided = true;
                var alert = new AlertEventArgs(filePath);
                ViewModelOpenFileAlert.Invoke(this, alert);
                return;
            }
            try
            {
                this.ListViewCursor = Cursors.AppStarting;
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = filePath,
                    UseShellExecute = true
                };
                using (var pro = new Process())
                {
                    pro.StartInfo = psi;
                    await Task.Run(() => pro.Start());
                }
            }
            catch (System.ComponentModel.Win32Exception)
            {
                MessageBox.Show("関連付けのされていないファイルは開けません");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            await Task.Delay(1000);
            this.ListViewCursor = Cursors.Default;
        }
        public void ExportCsv()
        {
            var textLines = new List<string>();
            textLines.Add("Num,FileName,Extension,Alias,Size,FilePath");
            lock (_lock)
            {
                for (int i = 0; i < this.DisplayFileInfos.Count; i++)
                {
                    textLines.Add(i.ToString() + "," +
                        "\"" + this.DisplayFileInfos.ElementAt(i).FileName() + "\"," +
                        "\"" + this.DisplayFileInfos.ElementAt(i).Extension() + "\"," +
                        "\"" + this.DisplayFileInfos.ElementAt(i).Alias + "\"," +
                        this.DisplayFileInfos.ElementAt(i).Size + "," +
                        "\"" + this.DisplayFileInfos.ElementAt(i).FilePath + "\""
                    );
                }
            }
            var filePath = Path.GetTempFileName();
            using (var writer = new StreamWriter(filePath, false, System.Text.Encoding.GetEncoding("shift-jis")))
            {
                writer.WriteLine(string.Join("\r\n", textLines));
            }
            string newFilePath;
            var type = Type.GetTypeFromProgID("Excel.Application");
            if (type == null)
            {
                var dialog = new SaveFileDialog();
                dialog.FileName = "FileSearchApp_SearchResult.csv";
                dialog.InitialDirectory = "%UserProfile%Documents";
                dialog.Filter = "CSVファイル(*.csv)|*.html|すべてのファイル(*.*)|*.*";
                dialog.FilterIndex = 1;
                dialog.Title = "保存先のファイルを選択してください";
                dialog.OverwritePrompt = true;
                if (dialog.ShowDialog() == DialogResult.OK){
                    newFilePath = dialog.FileName;
                    File.Move(filePath, newFilePath);
                }else{
                    return;
                }
            }else{
                newFilePath = filePath.Replace(".tmp", ".csv");
                File.Move(filePath, newFilePath);
                ProcessStartInfo psInfo = new ProcessStartInfo
                {
                    FileName = "excel.exe",
                    Arguments = newFilePath,
                    UseShellExecute = true,
                    RedirectStandardOutput = false,
                    CreateNoWindow = true
                };
                Process.Start(psInfo);
            }
        }
        public void SortListView(int pColumnIndex)
        {
            SortOrder order;
            if (_previousSortColumn == pColumnIndex){
                if (_previousSortOrder == SortOrder.Ascending){
                    order = SortOrder.Descending;
                }else{
                    order = SortOrder.Ascending;
                }
            }else{
                order = SortOrder.Ascending;
            }
            _previousSortOrder = order;
            _previousSortColumn = pColumnIndex;
            this.DisplayFileInfos.Sort(this.ListViewColumnHeaders[pColumnIndex].Text, order);
        }
        public Task<ExFileInfo> GetExFileInfoAsync()
        {
            var result = Task.Run(() => this.DisplayFileInfos.ElementAt(this.SelectionIndex));
            return result;
        }
        public ExFileInfo GetExFileInfo(int pIndex)
        {
            return this.DisplayFileInfos.ElementAtDirtyRead(pIndex);
        }
        public void ApplyFilter(Func<ExFileInfo, bool> pFilter)
        {
            this.DisplayFileInfos.ApplyFilter(pFilter);
            DisplayUpdate();
        }
        public bool IsSelected(int pIndex)
        {
            bool res = this.SelectedIndices.Contains(pIndex);
            return res | (this.SelectionIndex == pIndex);
        }
        public void SelectAll()
        {
            for (int i = 0; i < this.DisplayFileInfos.Count; i++)
            {
                this.SelectedIndices.Add(i);
                this.SelectionIndex = 0;
            }
        }
        public void UnSelectAll()
        {
            this.SelectedIndices.Clear();
            this.SelectionIndex = -1;
        }
        public void StartUpdateTimer()
        {
            this._displayUpdateTimer.Start();
        }
        public void StopUpdateTimer()
        {
            this._displayUpdateTimer.Stop();
            DisplayUpdate();
        }
        public void DisplayUpdate()
        {
            lock (_lock)
            {
                this.VirtualListSize = this.DisplayFileInfos.Count;
            }
        }
        // ============================================================
        // = 説明：プロパティ
        // ============================================================
        private int _virtualListSize;
        public int VirtualListSize
        {
            get { return _virtualListSize; }
            private set
            {
                _virtualListSize = value;
                var args = new ViewModelVirtualListSizeChangedEventArgs(_virtualListSize);
                ViewModelVirtualListSizeChanged.Invoke(this, args);
            }
        }
        private Cursor _listViewCursor = Cursors.Default;
        public Cursor ListViewCursor
        {
            get { return _listViewCursor; }
            private set
            {
                _listViewCursor = value;
                var args = new ViewModelListViewCursorChangedEventArgs(_listViewCursor);
                ViewModelListViewCursorChanged.Invoke(this, args);
            }
        }
        public MExFileInfoCollection DisplayFileInfos { get; private set; }
        private int _selectionIndex = -1;
        public int SelectionIndex
        {
            get { return _selectionIndex; }
            set
            {
                _selectionIndex = value;
                this.SelectedIndices.Add(value);
            }
        }
        SortedSet<int> _selectedIndices = new SortedSet<int>();
        public SortedSet<int> SelectedIndices
        {
            get
            {
                _selectedIndices.Remove(-1);
                return _selectedIndices;
            }
            set { _selectedIndices = value; }
        }
        public ListViewItem SelectionItem { get; set; } //選択を変更するときに前に選択していたアイテムのプロパティを変更するために保持してる
        public List<ToolStripMenuItem> ListViewMenuItems { get; set; }
        public ColumnHeader[] ListViewColumnHeaders { get; private set; }
        public bool AliasEnabled { get; set; }
        // ============================================================
        // = イベント
        // ============================================================
        public event EventHandler<ViewModelVirtualListSizeChangedEventArgs> ViewModelVirtualListSizeChanged = delegate { };
        public event EventHandler<ViewModelListViewCursorChangedEventArgs> ViewModelListViewCursorChanged = delegate { };
        public event EventHandler<AlertEventArgs> ViewModelOpenFileAlert = delegate { };
    }
}