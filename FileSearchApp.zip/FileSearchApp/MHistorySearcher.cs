using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;
using System.Timers;

namespace FileSearchApp
{
    public partial class MHistorySearcher : ISearcher
    {
        private BusyChecker _bufChecker = new BusyChecker(25, 1000);
        private BusyChecker _mainDataChecker = new BusyChecker(25, 1000);
        private SortedSet<string> _excludeDir = new SortedSet<string>();
        private object _lock = new object();
        private System.Timers.Timer _bufferFlushTimer = new System.Timers.Timer();
        private SimpleBuffer<string> _buf = new SimpleBuffer<string>();
        SortedKeyValue _index = new SortedKeyValue();
        public MHistorySearcher()
        {
            this.GetAlias = str1 => string.Empty;
            this.GetExcludeDirectory = () => new List<string>();
            this.SearchWords = new List<string>();
            this.RunActionWhenFileFound = new List<Action<ExFileInfo>>();
            _bufferFlushTimer.Interval = 1000;
            _bufferFlushTimer.Elapsed += new System.Timers.ElapsedEventHandler((s, e) =>
            {

                if (_bufChecker.IsBusy & _mainDataChecker.IsBusy)
                {
                    return;
                }
                FlushBuffer();
            });
            _bufferFlushTimer.Start();
        }
        ~MHistorySearcher()
        {
            _bufferFlushTimer.Stop();
            _bufferFlushTimer.Dispose();
        }
        public Task StartSearchAsync(CancellationToken ct)
        {
            var tsk = Task.Run(() =>
            {
                foreach (var info in GetResultAndRunSearch(this.SearchWords, ct))
                {
                    foreach (var method in this.RunActionWhenFileFound)
                    {
                        method(info);
                    }
                }
            });
            return tsk;
        }
        public IEnumerable<ExFileInfo> GetResultAndRunSearch(List<string> pSearchWords, CancellationToken cancellationToken)
        {
            _bufferFlushTimer.Stop();
            if (pSearchWords.Count == 0)
            {
                yield break;
            }
            foreach (var val in this.GetExcludeDirectory())
            {
                _excludeDir.Add(val);
            }
            var removeFilePaths = new List<string>();
            lock (_lock)
            {
                foreach (var keyValue in _index.GetKeyValues())
                {
                    _mainDataChecker.Notice();
                    if (cancellationToken.IsCancellationRequested){
                        yield break;
                    }
                    if (IsExcludeDirectory(keyValue.Key)){
                        removeFilePaths.Add(keyValue.Key);
                        continue;
                    }
                    foreach (var word in pSearchWords)
                    {
                        if (MyTool.FuzzyContains(word, ExFileInfo.GetFileNameAndExt(keyValue.Key)) |
                            MyTool.FuzzyContains(word, this.GetAlias(ExFileInfo.GetFileName(keyValue.Key)))
                        ){
                            yield return new ExFileInfo(keyValue.Key);
                            break;
                        }
                    }
                }
            }
            foreach (var val in removeFilePaths)
            {
                Remove(val);
            }
            _bufferFlushTimer.Start();
        }
        public List<ExFileInfo> GetExFileInfos(string pFileName)
        {
            var start = new IndexKeyValue(pFileName, IndexKeyValue.UnderOrOver.Under);
            var end = new IndexKeyValue(pFileName, IndexKeyValue.UnderOrOver.Over);
            int sIdx = _index.InsertIndexOfUnLock(start, false);
            int eIdx = _index.InsertIndexOfUnLock(end, false);
            var infos = new List<ExFileInfo>();
            for (int i = sIdx; i < eIdx; i++)
            {
                infos.Add(new ExFileInfo(_index.ElementAt(i).Key));
            }
            return infos;
        }
        public void Remove(string pFilePath)
        {
            lock (_lock)
            {
                _mainDataChecker.Notice();
                _index.Remove(CreateIndexKeyValue(pFilePath));
            }
        }
        public bool TryAdd(string pFilePath)
        {
            lock (_lock)
            {
                _mainDataChecker.Notice();
                return _index.Add(CreateIndexKeyValue(pFilePath));;
            }
        }
        public void AddToBuffer(string pFilePath)
        {
            _bufChecker.Notice();
            _buf.Add(pFilePath);
        }
        public void FlushBuffer()
        {
            lock (_lock)
            {
                foreach (var val in _buf.Flush())
                {
                    _index.Add(CreateIndexKeyValue(val));
                }
            }
        }
        public void PathMaintenance(int pChecks)
        {
            foreach (var val in this.GetExcludeDirectory())
            {
                _excludeDir.Add(val);
            }
            lock (_lock)
            {
                if (_index.Count == 0)
                {
                    return;
                }
                var rdm = new Random();
                for (int i = 0; i < pChecks; i++)
                {
                    _mainDataChecker.Notice();
                    int idx = rdm.Next(0, _index.Count - 1);
                    var path = _index.ElementAt(idx).Key;
                    if ((File.Exists(path) | Directory.Exists(path)) &
                        !IsExcludeDirectory(path)
                    ){
                        continue;
                    }
                    _index.Remove(_index.ElementAt(idx));
                }
            }
        }
        private IndexKeyValue CreateIndexKeyValue(string pFilePath)
        {
            return new IndexKeyValue(pFilePath, ExFileInfo.GetFileName(pFilePath));
        }
        private bool IsExcludeDirectory(string pFilePath)
        {
            foreach (var val in _excludeDir)
            {
                var exldPath = val;
                if (pFilePath.ToLower().StartsWith(exldPath.ToLower()))
                {
                    return true;
                }
            }
            return false;
        }
        public void SetKeyWords(List<string> pSearchWords)
        {
            this.SearchWords = pSearchWords;
        }
        public void Save(Action<IEnumerable<string>> pSaveMethod)
        {
            FlushBuffer();
            lock (_lock)
            {
                pSaveMethod(_index.GetKeys());
            }
        }
        public void Read(Func<List<string>> pReadMethod)
        {
            Func<List<IndexKeyValue>> func = () =>
            {
                return pReadMethod()
                    .AsParallel()
                    .Select(val => CreateIndexKeyValue(val))
                    .ToList();
            };
            _index.AddRangeSorted(func);
            //_index.AddRange(func().Distinct().ToList());
        }
        public Func<string, string> GetAlias;
        public Func<List<string>> GetExcludeDirectory { get; set; }
        public List<string> SearchWords { get; set; }
        public List<Action<ExFileInfo>> RunActionWhenFileFound { get; private set; }
    }
    public partial class MHistorySearcher
    {
        private class BusyChecker
        {
            object _lock = new object();
            int _max; int _before = 0; int _now = 0;
            private System.Timers.Timer _busyCheckTimer = new System.Timers.Timer();
            public BusyChecker(int pMax, int pIntervalMilliseconds)
            {
                _max = pMax;
                _busyCheckTimer.Interval = pIntervalMilliseconds;
                _busyCheckTimer.Elapsed += new System.Timers.ElapsedEventHandler(BusyCheck);
                _busyCheckTimer.Start();
            }
            ~BusyChecker() { _busyCheckTimer.Dispose(); }
            public void Notice() { lock (_lock) { _now++; }; }
            void BusyCheck(object s, ElapsedEventArgs e)
            {
                bool result;
                lock (_lock)
                {
                    result = _now - _before > _max;
                    _before = 0; _now = 0;
                }
                this.IsBusy = result;
            }
            public bool IsBusy { get; private set; }
        }
    }
}