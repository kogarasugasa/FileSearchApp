using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Threading;

namespace FileSearchApp
{
    public class ModelMessageReceivedEventArgs
    {
        private string _val;
        public ModelMessageReceivedEventArgs(string args)
        {
            _val = args;
        }
        public string Value { get { return _val; } }
    }
    public class AlertEventArgs
    {
        private string _val;
        public AlertEventArgs(string args)
        {
            _val = args;
        }
        public string Value { get { return _val; } }
    }
    public class ViewModelListViewCursorChangedEventArgs
    {
        private Cursor _val;
        public ViewModelListViewCursorChangedEventArgs(Cursor args) { _val = args; }
        public Cursor Value { get { return _val; } }
    }
    public class ViewModelVirtualListSizeChangedEventArgs
    {
        private int _val;
        public ViewModelVirtualListSizeChangedEventArgs(int args) { _val = args; }
        public int Value { get { return _val; } }
    }
    public class ViewModelRunCaptionChangedEventArgs
    {
        private string _val;
        public ViewModelRunCaptionChangedEventArgs(string args) { _val = args; }
        public string Value { get { return _val; } }
    }
    public class ExFileInfo
    {
        object _lock = new object();
        public ExFileInfo()
        {
            _filePath = string.Empty;
            _lastWriteTime = DateTime.MinValue;
            _size = 0;
            _alias = string.Empty;
        }
        public ExFileInfo(string pFilePath)
        {
            _filePath = pFilePath;
            _lastWriteTime = DateTime.MinValue;
            _size = 0;
            _alias = string.Empty;
        }
        public static string GetFileName(string pFilePath)
        {
            if (pFilePath.Length - pFilePath.LastIndexOf(".") > 5)
            {
                return pFilePath.Substring(pFilePath.LastIndexOf("\\") + 1);
            }
            return Path.GetFileNameWithoutExtension(pFilePath);
        }
        public static string GetFileNameAndExt(string pFilePath)
        {
            if (pFilePath.Length - pFilePath.LastIndexOf(".") > 5)
            {
                return pFilePath.Substring(pFilePath.LastIndexOf("\\") + 1);
            }
            return Path.GetFileName(pFilePath);
        }
        public string FileName()
        {
            lock (_lock)
            {
                if (FilePath.Length - FilePath.LastIndexOf(".") > 5)
                {
                    return FilePath.Substring(FilePath.LastIndexOf("\\") + 1);
                }
                return Path.GetFileNameWithoutExtension(FilePath);
            }
        }
        public string Extension()
        {
            lock (_lock)
            {
                if (FilePath.Length - FilePath.LastIndexOf(".") > 5)
                {
                    return "";
                }
                return Path.GetExtension(FilePath);
            }
        }
        public override string ToString()
        {
            lock (_lock)
            {
                return FilePath;
            }
        }
        string _filePath;
        public string FilePath { get { lock (_lock) { return _filePath;}} set { lock (_lock) { _filePath = value; }} }
        DateTime _lastWriteTime;
        public DateTime LastWriteTime { get { lock (_lock) { return _lastWriteTime; }} set { lock (_lock) { _lastWriteTime = value; }} }
        decimal _size;
        public decimal Size { get { lock (_lock) { return _size; }} set { lock (_lock) { _size = value; }} }
        string _alias;
        public string Alias { get { lock (_lock) { return _alias; }} set {lock (_lock) { _alias = value;}} }
        bool _invalided;
        public bool Invalided { get { lock (_lock) { return _invalided; }} set {lock (_lock) { _invalided = value;}} }
    }
    public struct SizePosition
    {
        public int Top;
        public int Left;
        public int Width;
        public int Height;
        public SizePosition(List<int> pTop_Left_Width_Height)
        {
            if (pTop_Left_Width_Height.Count < 4)
            {
                this.Top = 0;
                this.Left = 0;
                this.Width = 0;
                this.Height = 0;
            }
            else
            {
                this.Top = pTop_Left_Width_Height[0];
                this.Left = pTop_Left_Width_Height[1];
                this.Width = pTop_Left_Width_Height[2];
                this.Height = pTop_Left_Width_Height[3];
            }
        }
        public List<int> ToList()
        {
            var list = new List<int>()
            {
                this.Top,
                this.Left,
                this.Width,
                this.Height
            };
            return list;
        }
    }
    public static class MyTool
    {
        public static bool FuzzyContains(string pKeyWord, string pWord) // 「*」を使ったあいまい検索
        {
            if (pKeyWord.Length == 0)
            {
                return false;
            }
            var loKeyWord = pKeyWord.ToLower();
            var loWord = pWord.ToLower();
            var keyWordSplit = loKeyWord.Split('*');
            int searchPos = 0;
            foreach (var val in keyWordSplit)
            {
                if (val == "")
                {
                    continue;
                }
                int findPos = loWord.IndexOf(val, searchPos);
                if (findPos == -1)
                {
                    return false;
                }
                searchPos = findPos + val.Length;
            }
            return true;
        }
    }
    public class StreamString
    {
        private Stream ioStream;
        private UnicodeEncoding streamEncoding;

        public StreamString(Stream ioStream)
        {
            this.ioStream = ioStream;
            streamEncoding = new UnicodeEncoding();
        }

        public string ReadString()
        {
            int len = 0;

            len = ioStream.ReadByte() * 256;
            len += ioStream.ReadByte();
            byte[] inBuffer = new byte[len];
            ioStream.Read(inBuffer, 0, len);

            return streamEncoding.GetString(inBuffer);
        }

        public int WriteString(string outString)
        {
            byte[] outBuffer = streamEncoding.GetBytes(outString);
            int len = outBuffer.Length;
            if (len > UInt16.MaxValue)
            {
                len = (int)UInt16.MaxValue;
            }
            ioStream.WriteByte((byte)(len / 256));
            ioStream.WriteByte((byte)(len & 255));
            ioStream.Write(outBuffer, 0, len);
            ioStream.Flush();

            return outBuffer.Length + 2;
        }
    }
    public interface ISearcher
    {
        Task StartSearchAsync(CancellationToken ct);
        void SetKeyWords(List<string> pKeyWords);
    }
    public static class FileSearchAppPipeName
    {
        public static string Value = "FileSearchAppPipeName_1157954612354987";
    }
    public class SimpleBuffer<T>
    {
        object _lock = new object();
        object _lockFlush = new object();
        List<List<T>> _jag;
        public SimpleBuffer()
        {
            _jag = new List<List<T>>();
            _jag.Add(new List<T>());
        }
        public IEnumerable<T> Flush()
        {
            lock (_lockFlush)
            {
                lock (_lock)
                {
                    _jag.Insert(0, new List<T>());
                }
                foreach (var val in _jag[1])
                {
                    yield return val;
                }
                _jag.RemoveAt(1);
            }
        }
        public void Add(T pValue)
        {
            lock (_lock)
            {
                _jag[0].Add(pValue);
            }
        }
        public int CollectionsCount
        {
            get
            {
                lock (_lock) { return _jag.Count; }
            }
        }
        public int Count
        {
            get
            {
                lock (_lock)
                {
                    int cnt = 0;
                    foreach (var list in _jag)
                    {
                        foreach (var val in list)
                        {
                            cnt++;
                        }
                    }
                    return cnt;
                }
            }
        }
    }
    public class TaskCancellationTokenSourceCollection
    {
        object _lock = new object();
        int _nextId = 0;
        List<TaskCancellationTokenSource> tasks = new List<TaskCancellationTokenSource>();
        
        public int Add(Action<CancellationToken> pCancelableAction)
        {
            lock (_lock)
            {
                int id = _nextId++;
                var cts = new CancellationTokenSource();
                var task = Task.Run(() => pCancelableAction(cts.Token));
                tasks.Add(new TaskCancellationTokenSource(id, task, cts));
                return id;
            }
        }
        public void CancelAll()
        {
            lock (_lock)
            {
                while (tasks.Count != 0)
                {
                    var removeItems = new List<int>();
                    for (int i = 0; i < tasks.Count; i++)
                    {
                        if (tasks[i].CancelableTask.IsCompleted){
                            tasks[i].CTS.Dispose();
                            removeItems.Add(i);
                        }else{
                            tasks[i].CTS.Cancel();
                            Task.Delay(50).Wait();
                        }
                    }
                    removeItems.Sort();
                    for (int i = removeItems.Count - 1; i >= 0; i--)
                    {
                        tasks.RemoveAt(removeItems[i]);
                    }
                }
            }
        }
        public void CancelAt(int pId)
        {
            int removeIndex = -1;
            lock (_lock)
            {
                if (tasks.Count == 0){
                    return;
                }
                for (int i = 0; i < tasks.Count; i++)
                {
                    if (tasks[i].Id == pId){
                        removeIndex = i;
                        break;
                    }
                }
                if (removeIndex == -1){
                    return;
                }
                tasks[removeIndex].CTS.Cancel();
                while (!tasks[removeIndex].CancelableTask.IsCompleted)
                {
                    Task.Delay(50).Wait();
                }
                tasks[removeIndex].CTS.Dispose();
                tasks.RemoveAt(removeIndex);
            }
        }
        public void Wait(int pId)
        {
            foreach (var val in tasks)
            {
                if (val.Id == pId){
                    while (!val.CancelableTask.IsCompleted)
                    {
                        Task.Delay(100).Wait();
                    }
                    break;
                }
            }
        }
        private class TaskCancellationTokenSource
        {
            public TaskCancellationTokenSource(int pId, Task pCancelableTask, CancellationTokenSource pCancellationTokenSource)
            {
                this.Id = pId;
                this.CancelableTask = pCancelableTask;
                this.CTS = pCancellationTokenSource;
            }
            public int Id { get; private set; }
            public Task CancelableTask { get; private set; }
            public CancellationTokenSource CTS { get; private set; }
        }
    }
    public class IndexKeyValue : IComparable<IndexKeyValue>
    {
        public enum UnderOrOver { Under = -1, Neutral = 0, Over = 1 }
        static IndexKeyValueComparer _compr = new IndexKeyValueComparer();
        public IndexKeyValue(string pKey, string pValue)
        {
            this.Key = pKey;
            this.Value = pValue;
            this.Stance = UnderOrOver.Neutral;
        }
        public IndexKeyValue(string pValue, UnderOrOver pStance)
        {
            this.Key = string.Empty;
            this.Value = pValue;
            this.Stance = pStance;
        }
        public string Key { get; private set; }
        public UnderOrOver Stance { get; private set; }
        public string Value { get; private set; }
        public int CompareTo(IndexKeyValue other)
        {
            return _compr.Compare(this, other);
        }
        public static void SetOrder(int pKey, int pValue, int pStance)
        {
            _compr = new IndexKeyValueComparer(pKey,pValue,pStance);
        }
    }
    public class IndexKeyValueComparer : IComparer<IndexKeyValue>
    {
        int _keyOrder = 1; int _valueOrder = 100; int _stance = 10;
        public IndexKeyValueComparer(){}
        public IndexKeyValueComparer(int pKey, int pValue, int pStance)
        {
            _keyOrder = pKey;
            _valueOrder = pValue;
            _stance = pStance;
        }
        public int Compare(IndexKeyValue x, IndexKeyValue y)
        {
            int comp = 0;
            comp += x.Key.ToLower().CompareTo(y.Key.ToLower()) * _keyOrder;
            comp += x.Stance.CompareTo(y.Stance) * _stance;
            comp += x.Value.ToLower().CompareTo(y.Value.ToLower()) * _valueOrder;
            return comp;
        }
    }
    public class SortedKeyValue
    {
        object _lock = new object();
        List<IndexKeyValue> _index = new List<IndexKeyValue>();
        public bool Add(IndexKeyValue pKeyValue)
        {
            lock (_lock)
            {
                return AddUnLock(pKeyValue);
            }
        }
        public bool Add(Func<IndexKeyValue> pFunc)
        {
            lock (_lock)
            {
                return AddUnLock(pFunc());
            }
        }
        public void AddRange(List<IndexKeyValue> pList)
        {
            lock (_lock)
            {
                foreach (var val in pList)
                {
                    AddUnLock(val);
                }
            }
        }
        public void AddRangeSorted(Func<List<IndexKeyValue>> pFunc)
        {
            lock (_lock)
            {
                _index.AddRange(pFunc());
            }
        }
        public void AddRangeSorted(List<IndexKeyValue> pList)
        {
            lock (_lock)
            {
                _index.AddRange(pList);
            }
        }
        private bool AddUnLock(IndexKeyValue pKeyValue)
        {
            int insertIdx = InsertIndexOfUnLock(pKeyValue, false);
            if (insertIdx >= _index.Count){
                _index.Add(pKeyValue);
                return true;
            }
            if (_index[insertIdx].CompareTo(pKeyValue) == 0){
                return false;
            }
            _index.Insert(insertIdx, pKeyValue);
            return true;
        }
        public bool Remove(IndexKeyValue pKeyValue)
        {
            lock (_lock)
            {
                int idx = InsertIndexOfUnLock(pKeyValue, true);
                if (idx >= 0){
                    _index.RemoveAt(idx);
                    return true;
                }
                return false;
            }
        }
        public bool Remove(Func<IndexKeyValue> pFunc)
        {
            lock (_lock)
            {
                return _index.Remove(pFunc());
            }
        }
        public IEnumerable<IndexKeyValue> GetKeyValues()
        {
            lock (_lock)
            {
                foreach (var val in _index)
                {
                    yield return val;
                }
            }
        }
        public IEnumerable<string> GetKeys()
        {
            lock (_lock)
            {
                foreach (var val in _index)
                {
                    yield return val.Key;
                }
            }
        }
        public List<IndexKeyValue> GetInnerCollection()
        {
            return _index;
        }
        public void BlockIn(IndexKeyValueComparer pComparer, Action pBlock)
        {
            lock (_lock)
            {
                _index.Sort(pComparer);
                pBlock();
                _index.Sort();
            }
        }
        public IndexKeyValue ElementAt(int pIndex)
        {
            lock (_lock)
            {
                return _index[pIndex];
            }
        }
        public int InsertIndexOfUnLock(IndexKeyValue pKeyValue, bool pExactMatch) //Insertすべき位置を返す
        {
            int pivot = _index.Count / 2;
            int start = 0;
            int end = _index.Count - 1;
            while (_index.Count > 0)
            {
                int compareTo = pKeyValue.CompareTo(_index[pivot]);
                if (compareTo > 0){
                    start = Math.Min(pivot + 1, end);
                    pivot = pivot + (end - pivot) / 2;
                }else{
                    end = Math.Max(pivot - 1, start);
                    pivot = start + (pivot - start) / 2;
                }
                if (start == end){
                    var comp = pKeyValue.CompareTo(_index[start]);
                    int before;
                    if (comp == 0){
                        return start;
                    }else if (comp > 0){
                        before = 1;
                    }else{
                        before = -1;
                    }
                    int curIdx = start;
                    while (true)
                    {
                        var comp2 = pKeyValue.CompareTo(_index[curIdx]);
                        if (comp2 == 0){
                            comp2 = 0;
                        }else if (comp2 > 0){
                            comp2 = 1;
                        }else{
                            comp2 = -1;
                        }
                        int after = comp2;
                        if (before != after){
                            if (after == 0){
                                return curIdx;
                            }
                            if (pExactMatch){
                                return -1;
                            }
                            if (after > 0){
                                return curIdx + after;
                            }
                            if (after < 0){
                                return curIdx;
                            }
                        }
                        before = after;
                        curIdx += after;
                        if (curIdx >= _index.Count){
                            return curIdx;
                        }
                        if (curIdx < 0){
                            return 0;
                        }
                    }
                }
            }
            return 0;
        }
        public int Count
        {
            get
            {
                lock (_lock) { return _index.Count; }
            }
        }
    }
}