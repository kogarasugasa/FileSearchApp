using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms.VisualStyles;

namespace FileSearchApp
{
    public class MTagSearcher : ISearcher
    {
        public MTagSearcher()
        {
            this.GetSource = (a, b) => new List<ExFileInfo>();
            this.GetTags = (a) => new List<string>();
            this.GetNames = (a) => new List<string>();
            this.GetAllTags = () => new List<string>();
            this.GetExFileInfos = (a) => new List<ExFileInfo>();
            this.SearchTags = new List<string>();
            this.RunActionWhenFileFound = new List<Action<ExFileInfo>>();
            this.GetSource = (a, b) => new List<ExFileInfo>();
        }
        public async Task StartSearchAsync(CancellationToken ct)
        {
            this.SearchTags = MInputBoxTag.GetTags(this.GetAllTags(), new List<string>());
            await Task.Run(() =>
            {
                foreach (var info in GetResultAndRunSearch(ct))
                {
                    foreach (var method in this.RunActionWhenFileFound)
                    {
                        method(info);
                    }
                }
            });
        }
        public IEnumerable<ExFileInfo> GetResultAndRunSearch(CancellationToken cancellationToken)
        {
            if (this.SearchTags.Count() == 0){
                yield break;
            }
            var fileNames = new List<string>();
            foreach (var tag in this.SearchTags)
            {
                fileNames.AddRange(this.GetNames(tag));
            }
            fileNames = fileNames.Distinct().ToList();
            foreach (var name in fileNames)
            {
                foreach (var info in this.GetExFileInfos(name))
                {
                    yield return info;
                }
            }
        }
        public void SetKeyWords(List<string> pTags)
        {
            this.SearchTags = pTags;
        }
        public Func<List<string>, CancellationToken, IEnumerable<ExFileInfo>> GetSource { private get; set; }
        public Func<string, List<string>> GetTags { private get; set; }
        public Func<string, List<string>> GetNames { private get; set; }
        public Func<List<string>> GetAllTags { private get; set; }
        public Func<string, List<ExFileInfo>> GetExFileInfos { get; set; }
        public List<Action<ExFileInfo>> RunActionWhenFileFound { get; private set; }
        public List<string> SearchTags { get; set; }
    }
}