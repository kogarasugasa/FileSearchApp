using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace FileSearchApp
{
    public class VMDisabledHistory
    {
        object _lock = new object();
        Action<string> _removeHis;
        CancellationTokenSource _cts = new CancellationTokenSource();
        public VMDisabledHistory(Action<string> pRemoveHistory, VMListView pViewModelListView)
        {
            _removeHis = pRemoveHistory;
            this.ViewModelListView = pViewModelListView;
            this.SearchWords = string.Empty;
            this.WindowProperty = new SizePosition();
            this.SearchResult = new List<ExFileInfo>();
            this.Searcher = new Dictionary<ISearcher, Func<bool>>();
        }
        ~VMDisabledHistory()
        {
            _cts.Cancel();
            _cts.Dispose();
        }
        public async Task StartSearch()
        {
            lock (_lock)
            {
                if (this.IsSearching){
                    return;
                }
                this.IsSearching = true;
            }
            _cts.Dispose();
            _cts = new CancellationTokenSource();
            //Runボタンがクルクルし始める
            var anime = WaitingAnimationAsync(_cts.Token);
            //検索中にリストを更新するタイマーを開始
            //検索を開始する
            var tasks = new List<Task>();
            foreach (var val in this.Searcher)
            {
                if (val.Value())
                {
                    val.Key.SetKeyWords(this.SearchWords.Split(':').ToList());
                    tasks.Add(val.Key.StartSearchAsync(_cts.Token));
                }
            }
            await Task.WhenAll(tasks);
            //情報を更新する
            var disabledInfos = new List<ExFileInfo>();
            for (int i = 0; i < this.ViewModelListView.DisplayFileInfos.Count; i++)
            {
                disabledInfos.Add(this.ViewModelListView.DisplayFileInfos.ElementAt(i));
            }
            foreach (var disabledInfo in disabledInfos)
            {
                foreach (var enabledInfo in this.SearchResult)
                {
                    if (disabledInfo.FileName() == enabledInfo.FileName()){
                        _removeHis(disabledInfo.FilePath);
                        disabledInfo.FilePath = enabledInfo.FilePath;
                        disabledInfo.Invalided = false;
                    }
                }
            }
            _cts.Cancel();
            lock (_lock)
            {
                this.IsSearching = false;
            }
        }
        public void CancelSearch()
        {
            _cts.Cancel();
        }
        private async Task WaitingAnimationAsync(CancellationToken cancellationToken)
        //検索中であることがわかる検索アニメーションを開始する
        {
            await Task.Run(() =>
            {
                try
                {
                    var disp = "||||";
                    for (int i = 0; i < 30; i++)
                    {
                        disp = disp + " ";
                    }
                    while (!cancellationToken.IsCancellationRequested)
                    {
                        var str = disp.Substring(disp.Length - 1, 1);
                        disp = disp.Substring(0, disp.Length - 1).Insert(0 ,str);
                        RunCaption = disp;
                        Task.Delay(50, cancellationToken).Wait();
                    }
                }
                finally
                {
                    RunCaption = "選択を検索し修正";
                }
            });
        }
        public void RemoveHistory(List<int> pIndices)
        {
            foreach (int i in pIndices)
            {
                var info = this.ViewModelListView.DisplayFileInfos.ElementAt(i);
                var path = info.FilePath;
                _removeHis(path);
                info.Invalided = false;
                info.Alias = "deleted";
            }
        }
        // ============================================================
        // = 説明：プロパティ
        // ============================================================
        public string SearchWords { get; set; }
        public bool IsSearching { get; private set; }
        public List<ExFileInfo> SearchResult { get; set; }
        private string _runCaption = "○";
        public string RunCaption
        {
            get { return _runCaption; }
            private set
            {
                _runCaption = value;
                var args = new ViewModelRunCaptionChangedEventArgs(_runCaption);
                ViewModeRunCaptionChanged.Invoke(this, args);
            }
        }
        public SizePosition WindowProperty { get; set; }
        public VMListView ViewModelListView { get; private set; }
        public Dictionary<ISearcher, Func<bool>> Searcher { get; private set; }
        // ============================================================
        // = 説明：イベント
        // ============================================================
        public event EventHandler<ViewModelRunCaptionChangedEventArgs> ViewModeRunCaptionChanged = delegate { };
    }
}