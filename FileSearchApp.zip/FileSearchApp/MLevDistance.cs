using System.Linq;
namespace FileSearchApp
{
    public static class LevDistanceClass
    {
        public static int LevDistance(string str1, string str2)
        {
            //コスト計算配列を準備
            int[,] costMatrix = new int[str2.Length + 1, str1.Length + 1];
            for (int i = 1; i <= str1.Length; i++)
            {
                costMatrix[0, i] = i;
            }
            for (int i = 1; i <= str2.Length; i++)
            {
                costMatrix[i, 0] = i;
            }
            //コスト計算
            int Min;
            for (int i = 1; i <= str2.Length; i++)
            {
                for (int j = 1; j <= str1.Length; j++)
                {
                    Min = 0;
                    if (str1.Substring(j - 1, 1) != str2.Substring(i - 1, 1)){
                        //小さい値を求める
                        if (costMatrix[i, j - 1] > costMatrix[i - 1, j]){
                            Min = costMatrix[i - 1, j];
                        }else{
                            Min = costMatrix[i, j - 1];
                        }
                        costMatrix[i, j] = Min + 1;
                    }else{
                        costMatrix[i, j] = costMatrix[i - 1, j - 1];
                    }
                }
            }
            return costMatrix[str2.Length, str1.Length];
        }
    }
}