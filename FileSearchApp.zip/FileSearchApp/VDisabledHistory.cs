using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace FileSearchApp
{
    public partial class VDisabledHistory : Form
    {
        ListView _listView = new ListView();
        Button _allSelectBtn = new Button();
        Button _allUnSelectBtn = new Button();
        Button _updBtn = new Button();
        Button _delBtn = new Button();
        VMDisabledHistory _viewModel;
        Func<ExFileInfo, bool> _filter;
        public VDisabledHistory(VMDisabledHistory pViewModel)
        {
            _viewModel = pViewModel;
            _filter = _viewModel.ViewModelListView.DisplayFileInfos.Filter;
            _viewModel.ViewModelListView.DisplayFileInfos.Filter = info => info.Invalided;
            InitializeComponent();
            InitializeEventSet();
        }
        private void InitializeComponent()
        {
            this.Text = "無効な履歴の管理";
            //全選択ボタン
            this.Controls.Add(_allSelectBtn);
            _allSelectBtn.Text = "全選択";
            _allSelectBtn.Top = 9;
            _allSelectBtn.Left = 10;
            _allSelectBtn.Height = 21;
            _allSelectBtn.Width = 90;
            //全解除ボタン
            this.Controls.Add(_allUnSelectBtn);
            _allUnSelectBtn.Text = "全解除";
            _allUnSelectBtn.Top = 9;
            _allUnSelectBtn.Left = _allSelectBtn.Left + _allSelectBtn.Width;
            _allUnSelectBtn.Height = 21;
            _allUnSelectBtn.Width = 90;
            //修正ボタン
            this.Controls.Add(_updBtn);
            _updBtn.Text = "選択を検索し修正";
            _updBtn.Top = 9;
            _updBtn.Left = _allUnSelectBtn.Left + _allUnSelectBtn.Width;
            _updBtn.Height = 21;
            _updBtn.Width = 150;
            //削除ボタン
            this.Controls.Add(_delBtn);
            _delBtn.Text = "選択を履歴から削除";
            _delBtn.Top = 9;
            _delBtn.Left = 5 + _updBtn.Left + _updBtn.Width;
            _delBtn.Height = 21;
            _delBtn.Width = 150;
            //リストビュー
            this.Controls.Add(_listView);
            _listView.Top = _allSelectBtn.Top + _allSelectBtn.Height + 5;
            _listView.Left = 10;
            _listView.Height = this.Height - _listView.Top - 50;
            _listView.Width = this.Width - 36;
            _listView.VirtualMode = true;
            _listView.MultiSelect = false;
            _listView.AllowColumnReorder = true;
            _listView.FullRowSelect = true;
            _listView.Scrollable = true;
            _listView.GridLines = true;
            _listView.HideSelection = false;
            _listView.View = View.Details;
            _listView.CheckBoxes = true;
            var cloneHead = new List<ColumnHeader>();
            foreach (var val in _viewModel.ViewModelListView.ListViewColumnHeaders)
            {
                cloneHead.Add((ColumnHeader)val.Clone());
            }
            _listView.Columns.AddRange(cloneHead.ToArray());
        }
    }
    public partial class VDisabledHistory
    {
        public void InitializeEventSet()
        {
            // ============================================================
            // = 説明：Viewからのイベント
            // ============================================================
            this.Load += new EventHandler((s, e) =>
            {
                this.Top = _viewModel.WindowProperty.Top;
                this.Left = _viewModel.WindowProperty.Left;
                this.Width = _viewModel.WindowProperty.Width;
                this.Height = _viewModel.WindowProperty.Height;
                this.Enabled = true;
            });
            this.SizeChanged += new EventHandler((s, e) =>
            {
                _listView.Height = this.Height - _listView.Top - 50;
                _listView.Width = this.Width - 36;
            });
            this.Shown += new EventHandler((s, e) =>
            {
                _listView.VirtualListSize = _viewModel.ViewModelListView.DisplayFileInfos.Count;
            });
            this.FormClosed += new FormClosedEventHandler((s, e) =>
            {
                _viewModel.ViewModelListView.DisplayFileInfos.Filter = _filter;
            });
            _allSelectBtn.Click += new EventHandler((s, e) =>
            {
                _viewModel.ViewModelListView.SelectAll();
                int maxCnt = _listView.VirtualListSize;
                if (maxCnt != 0){
                    _listView.RedrawItems(0, maxCnt - 1, false);
                }
            });
            _allUnSelectBtn.Click += new EventHandler((s, e) =>
            {
                _viewModel.ViewModelListView.UnSelectAll();
                var inds = new List<int>(_viewModel.ViewModelListView.SelectedIndices);
                int maxCnt = _listView.VirtualListSize;
                if (maxCnt != 0){
                    _listView.RedrawItems(0, maxCnt - 1, false);
                }
            });
            _updBtn.Click += new EventHandler(async (s, e) =>
            {
                if (_viewModel.IsSearching)
                {
                    _viewModel.CancelSearch();
                    return;
                }
                _viewModel.ViewModelListView.StartUpdateTimer();
                var names = new List<string>();
                foreach (var val in _viewModel.ViewModelListView.SelectedIndices)
                {
                    names.Add(_viewModel.ViewModelListView.GetExFileInfo(val).FileName());
                }
                _viewModel.SearchWords = string.Join(":", names);
                await _viewModel.StartSearch();
                _viewModel.ViewModelListView.ApplyFilter(_viewModel.ViewModelListView.DisplayFileInfos.Filter);
                _viewModel.ViewModelListView.StopUpdateTimer();
                _viewModel.ViewModelListView.UnSelectAll();
                this.RedrawListViewItems();
            });
            _delBtn.Click += new EventHandler((s, e) =>
            {
                _viewModel.RemoveHistory(_viewModel.ViewModelListView.SelectedIndices.ToList());
                _viewModel.ViewModelListView.UnSelectAll();
                this.RedrawListViewItems();
            });
            _listView.ItemSelectionChanged += new ListViewItemSelectionChangedEventHandler((s, e) =>
            {
                if (e.ItemIndex < 0){
                    return;
                }
                if (_viewModel.ViewModelListView.IsSelected(e.ItemIndex)){
                    _viewModel.ViewModelListView.SelectedIndices.Remove(e.ItemIndex);
                    _viewModel.ViewModelListView.SelectionIndex = -1;
                    _viewModel.ViewModelListView.SelectionItem = new ListViewItem();
                    e.Item.BackColor = System.Drawing.Color.White;
                }else{
                    _viewModel.ViewModelListView.SelectedIndices.Add(e.ItemIndex);
                    _viewModel.ViewModelListView.SelectionIndex = e.ItemIndex;
                    var info = _viewModel.ViewModelListView.GetExFileInfo(e.ItemIndex);
                    var item = _viewModel.ViewModelListView.ConvToListViewItem(info, e.ItemIndex);
                    _viewModel.ViewModelListView.SelectionItem = item;
                    e.Item.BackColor = System.Drawing.Color.SkyBlue;
                }
                e.Item.Focused = false;
                _listView.SelectedIndices.Clear();
            });
            _listView.KeyDown += new KeyEventHandler(async (s, e) =>
            {
                e.Handled = true;
                if (e.KeyCode == Keys.Down)
                {
                    if (_viewModel.ViewModelListView.SelectionIndex >= _viewModel.ViewModelListView.DisplayFileInfos.Count - 1)
                    {
                        return;
                    }
                    int nextIdx = _viewModel.ViewModelListView.SelectionIndex + 1;
                    _listView.SelectedIndices.Add(nextIdx);
                    _listView.EnsureVisible(nextIdx);
                }
                if (e.KeyCode == Keys.Up)
                {
                    if (_viewModel.ViewModelListView.SelectionIndex <= 0)
                    {
                        return;
                    }
                    int nextIdx = _viewModel.ViewModelListView.SelectionIndex - 1;
                    _listView.SelectedIndices.Add(nextIdx);
                    _listView.EnsureVisible(nextIdx);
                }
                if (e.KeyCode == Keys.Enter)
                {
                    int idx = _viewModel.ViewModelListView.SelectionIndex;
                    if (idx == -1)
                    {
                        return;
                    }
                    await _viewModel.ViewModelListView.OpenSelectionItemAsync();
                }
            });
            _listView.RetrieveVirtualItem += new RetrieveVirtualItemEventHandler((s, e) =>
            {
                var info = _viewModel.ViewModelListView.GetExFileInfo(e.ItemIndex);
                e.Item = _viewModel.ViewModelListView.ConvToListViewItem(info, e.ItemIndex);
                if (_viewModel.ViewModelListView.IsSelected(e.ItemIndex)){
                    e.Item.BackColor = System.Drawing.Color.SkyBlue;
                    e.Item.Selected = false;
                    e.Item.Focused = false;
                }else{
                    e.Item.BackColor = System.Drawing.Color.White;
                }
            });
            _listView.ColumnClick += new ColumnClickEventHandler((s, e) =>
            {
                _viewModel.ViewModelListView.SortListView(e.Column);
                _listView.VirtualListSize = 0;
                _listView.VirtualListSize = _viewModel.ViewModelListView.VirtualListSize;
            });
            _listView.DoubleClick += new EventHandler(async (s, e) =>
            {
                await _viewModel.ViewModelListView.OpenSelectionItemAsync();
            });
            // ============================================================
            // = 説明：ViewModelからのイベント
            // ============================================================
            _viewModel.ViewModelListView.ViewModelListViewCursorChanged += new EventHandler<ViewModelListViewCursorChangedEventArgs>((s, e) =>
            {
                _listView.Cursor = e.Value;
            });
            _viewModel.ViewModelListView.ViewModelVirtualListSizeChanged += new EventHandler<ViewModelVirtualListSizeChangedEventArgs>((s, e) =>
            {
                _listView.VirtualListSize = e.Value;
            });
            _viewModel.ViewModeRunCaptionChanged += new EventHandler<ViewModelRunCaptionChangedEventArgs>((s, e) =>
            {
                this.Invoke((MethodInvoker)delegate ()
                {
                    _updBtn.Text = e.Value;
                    //_runLabel.Text = e.Value;
                });
            });
        }
        public void RedrawListViewItems()
        {
            int rowHeight = 16; //1行あたりの高さ
            int headHeight = 28; //ヘッダなど、それ以外の高さ
            int displayRowsCnt = (_listView.Height - headHeight) / rowHeight + 5;
            if (_viewModel.ViewModelListView.DisplayFileInfos.LastReadIndex >= _viewModel.ViewModelListView.DisplayFileInfos.Count){
                return;
            }
            if (_viewModel.ViewModelListView.DisplayFileInfos.Count == 0){
                return;
            }
            var list = new List<int>();
            int start = _viewModel.ViewModelListView.DisplayFileInfos.LastReadIndex - displayRowsCnt;
            int end = _viewModel.ViewModelListView.DisplayFileInfos.LastReadIndex + displayRowsCnt;
            start = Math.Max(0, start);
            end = Math.Min(_viewModel.ViewModelListView.DisplayFileInfos.Count - 1, end);
            for (int i = start; i <= end; i++)
            {
                list.Add(i);
            }
            var updateIndeces = list;
            if (updateIndeces.Count == 0){
                return;
            }
            _listView.RedrawItems(updateIndeces.Min(), updateIndeces.Max(), false);
        }
    }
}
