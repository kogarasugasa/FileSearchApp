using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;
using System.Diagnostics;
using System.IO.Compression;

namespace FileSearchApp
{
    public class MSettings
    {
        string _searchDirFilePath;
        string _columnWidthFilePath;
        string _windowSizeFilePath;
        string _tagMSFilePath;
        string _fileTagsFilePath;
        string _searchResultHistoryFilePath;
        string _aliasFilePath;
        string _excludeDirectoryFilePath;
        string _readmeFilePath;
        readonly string _settingsDirFilePath = Application.StartupPath + @"\SettingsDir.txt";
        public MSettings()
        {
            var curDir = GetSettingsDir();
            if (!Directory.Exists(curDir)){
                curDir = Application.StartupPath;
                TryCreateSettingsDir();
            }
            _searchDirFilePath = curDir + @"\SettingsSearchDir.ini";
            _columnWidthFilePath = curDir + @"\SettingsColumnWidth.ini";
            _windowSizeFilePath = curDir + @"\SettingsWindowSize.ini";
            _tagMSFilePath = curDir + @"\SettingsTag.ini";
            _fileTagsFilePath = curDir + @"\SettingsTagAllocation.txt";
            _searchResultHistoryFilePath = curDir + @"\SettingsSearchResultPath.log.gz";
            _aliasFilePath = curDir + @"\SettingsAlias.ini";
            _excludeDirectoryFilePath = curDir + @"\SettingsExcludeDirectory.ini";
            _readmeFilePath = curDir + @"\Readme.txt";
        }
        public void WriteAlias(List<string> pAliases)
        {
            WriteSettings(_aliasFilePath, pAliases);
        }
        public List<string> GetAlias()
        {
            return this.ReadSettings(_aliasFilePath);
        }
        public void WriteSearchResultHistory(IEnumerable<string> pFilePaths)
        {
            WriteSettingsCompress(_searchResultHistoryFilePath, pFilePaths);
        }
        public List<string> GetSearchResultHistory()
        {
            return ReadSettingsDeCompress(_searchResultHistoryFilePath , 100000);
        }
        public void WriteFileNameTag(List<string> list)
        {
            WriteSettings(_fileTagsFilePath, list);
        }
        public List<string> GetFileNameTags()
        {
            return this.ReadSettings(_fileTagsFilePath);
        }
        public void TryCreateTagMS()
        {
            if (File.Exists(_tagMSFilePath)){
                return;
            }
            var line = new List<string>(){
                "// 以下の2文字は使用できません。設定データが破損する可能性があります",
                "// ,:",
            };
            WriteSettings(_tagMSFilePath, line);
        }
        public List<string> GetExcludeDirectory()
        {
            return this.ReadSettings(_excludeDirectoryFilePath);
        }
        public List<string> GetTagMS()
        {
            return this.ReadSettings(_tagMSFilePath);
        }
        public void OpenTagSettings()
        {
            if (!File.Exists(_tagMSFilePath)){
                TryCreateTagMS();
            }
            var psInfo = new ProcessStartInfo
            {
                FileName = _tagMSFilePath,
                UseShellExecute = true
            };
            using (var pro = new Process())
            {
                pro.StartInfo = psInfo;
                pro.Start();
            }
        }
        public void OpenDirectorySettings()
        {
            if(!File.Exists(_searchDirFilePath)){
                TryCreateSearchDirectorys();
            }
            var psInfo = new ProcessStartInfo
            {
                FileName = _searchDirFilePath,
                UseShellExecute = true
            };
            using (var pro = new Process())
            {
                pro.StartInfo = psInfo;
                pro.Start();
            }
        }
        public void OpenExcludeDirectorySettings()
        {
            if(!File.Exists(_excludeDirectoryFilePath)){
                TryCreateExcludeDirectory();
            }
            var psInfo = new ProcessStartInfo
            {
                FileName = _excludeDirectoryFilePath,
                UseShellExecute = true
            };
            using (var pro = new Process())
            {
                pro.StartInfo = psInfo;
                pro.Start();
            }
        }
        public void OpenReadme()
        {
            if(!File.Exists(_readmeFilePath)){
                return;
            }
            var psInfo = new ProcessStartInfo
            {
                FileName = _readmeFilePath,
                UseShellExecute = true
            };
            using (var pro = new Process())
            {
                pro.StartInfo = psInfo;
                pro.Start();
            }
        }
        public void WriteWindowSize(List<int> size)
        {
            var lines = size.Select(val => val.ToString()).ToList();
            lines.Insert(0, "//1行目がTop、2行目がLeft、3行目Width、4行目がHeight");
            WriteSettings(_windowSizeFilePath, lines);
        }
        public void WriteColumnWidth(List<int> width)
        {
            var lines = width.Select(val => val.ToString()).ToList();
            lines.Insert(0, "//先頭の列から順番に1行ずつ書き込む");
            WriteSettings(_columnWidthFilePath, width.Select(val => val.ToString()));
        }
        public List<int> GetWindowSize()
        {
            int width = 0;
            List<int> result = new List<int>();
            foreach (var str in ReadSettings(_windowSizeFilePath))
            {
                if (!int.TryParse(str, out width))
                {
                    return result;
                }
                result.Add(width);
            }
            return result;
        }
        public List<int> GetColumnWidth()
        {
            int width;
            List<int> result = new List<int>();
            foreach (var str in ReadSettings(_columnWidthFilePath))
            {
                if (!int.TryParse(str, out width))
                {
                    return result;
                }
                result.Add(width);
            }
            return result;
        }
        public void TryCreateExcludeDirectory()
        {
            if (File.Exists(_excludeDirectoryFilePath)){
                return;
            }
            var line = new List<string>(){
                "//除外したいフォルダのパスを入力してください",
                "//ここで設定したフォルダ以下の階層は検索結果から除外されます",
            };
            WriteSettings(_excludeDirectoryFilePath, line);
        }
        public void TryCreateSearchDirectorys()
        {
            if (File.Exists(_searchDirFilePath)){
                return;
            }
            var line = new List<string>(){
                "//フォルダパスを1行ずつ入力してください",
                @"C:\Users\UserName",
                @"D:",
            };
            WriteSettings(_searchDirFilePath, line);
        }
        public void TryCreateSettingsDir()
        {
            if (File.Exists(_settingsDirFilePath)){
                return;
            }
            var line = new List<string>(){
                "//一番上のフォルダパスだけが有効です",
                "//一つもない場合は実行ファイルと同じフォルダが",
                "//設定ファイルの保存場所として使用されます",
            };
            WriteSettings(_settingsDirFilePath, line);
        }
        public string GetSettingsDir()
        {
            var dirs = ReadSettings(_settingsDirFilePath);
            if (dirs.Count == 0){
                return string.Empty;
            }
            return dirs[0];
        }
        public List<string> GetSearchDirectorys()
        {
            return ReadSettings(_searchDirFilePath);
        }
        private List<string> ReadSettings(string settingFilePath)
        {
            if (!File.Exists(settingFilePath)){
                return new List<string>();
            }
            List<string> settingList = new List<string>();
            using (StreamReader stream = new StreamReader(settingFilePath, System.Text.Encoding.UTF8))
            {
                while (stream.EndOfStream == false)
                {
                    settingList.Add(stream.ReadLine());
                }
            }
            var result = new List<string>();
            foreach ( string str in settingList)
            {
                if (str.Length == 0){
                    continue;
                }
                if (str.StartsWith("//")){
                    continue;
                }
                result.Add(str);
            }
            return result;
        }
        private void WriteSettings(string pFilePath, IEnumerable<string> pLines)
        {
            try
            {
                using (StreamWriter stream = new StreamWriter(pFilePath))
                {
                    foreach(var val in pLines)
                    {
                        stream.WriteLine(val);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private List<string> ReadSettingsDeCompress(string settingFilePath , int pCapacity)
        {
            if (!File.Exists(settingFilePath)){
                return new List<string>();
            }
            List<string> settingList = new List<string>(pCapacity);
            using (var fileStream = File.Open(settingFilePath, FileMode.Open))
            using (var gzipStream = new GZipStream(fileStream, CompressionMode.Decompress))
            using (var reader = new StreamReader(gzipStream, System.Text.Encoding.UTF8))
            {
                while (reader.EndOfStream == false)
                {
                    settingList.Add(reader.ReadLine());
                }
            }
            var result = new List<string>();
            foreach ( string str in settingList)
            {
                if (str.Length == 0){
                    continue;
                }
                if (str.StartsWith("//")){
                    continue;
                }
                result.Add(str);
            }
            return result;
        }
        private void WriteSettingsCompress(string pFilePath, IEnumerable<string> pLines)
        {
            try
            {
                using (var fileStream = File.Create(pFilePath))
                using (var gzipStream = new GZipStream(fileStream, CompressionLevel.Optimal))
                using (var writer = new StreamWriter(gzipStream))
                {
                    foreach(var val in pLines)
                    {
                        writer.WriteLine(val);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}