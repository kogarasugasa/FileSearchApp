using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace FileSearchApp
{
    public class MTagManager
    {
        private List<string> _names = new List<string>();
        private List<string> _tags = new List<string>();
        public MTagManager()
        {
            this.GetAllTags = () => new List<string>();
        }
        public MTagManager(List<string> pSettingList)
        {
            if (pSettingList == null){
                pSettingList = new List<string>();
            }
            this.GetAllTags = () => new List<string>();
            Read(pSettingList);
        }
        public void Add(string pFileName, string pTag)
        {
            if (Exists(pFileName, pTag)){
                return;
            }
            _names.Add(pFileName);
            _tags.Add(pTag);
        }
        public void Remove(string pFileName, string pTag)
        {
            int startIdx = 0;
            bool matched = false;
            bool nothing = false;
            while (!(matched | nothing))
            {
                int namePos = _names.IndexOf(pFileName, startIdx);
                int tagPos = _tags.IndexOf(pTag, namePos);
                matched = namePos == tagPos;
                matched = matched & !(namePos == -1);
                nothing = tagPos == -1;
                startIdx = tagPos;
            }
            if (matched){
                _names.RemoveAt(startIdx);
                _tags.RemoveAt(startIdx);
            }
        }
        public bool Exists(string pFilename, string pTag)
        {
            var tags = GetTags(pFilename);
            foreach (var val in tags)
            {
                if (val == pTag){
                    return true;
                }
            }
            return false;
        }
        public List<string> GetTags(string FileName)
        {
            var searched = new List<string>();
            var startIdx = 0;
            while (startIdx < _names.Count)
            {
                var idx = _names.IndexOf(FileName, startIdx);
                if (idx == -1){
                    break;
                }
                searched.Add(_tags[idx]);
                startIdx = idx + 1;
            }
            var result = searched;
            return result;
        }
        public List<string> GetNames(string Tag)
        {
            var searched = new List<string>();
            var startIdx = 0;
            while (startIdx < _tags.Count)
            {
                var idx = _tags.IndexOf(Tag, startIdx);
                if (idx == -1){
                    break;
                }
                searched.Add(_names[idx]);
                startIdx = idx + 1;
            }
            var result = searched.Distinct().ToList();
            return result;
        }
        public List<string> GetNames(List<string> pTags)
        {
            var counter = new Dictionary<string, int>();
            for (int i = 0; i < _tags.Count; i++)
            {
                if (pTags.Contains(_tags[i])){
                    if (counter.ContainsKey(_names[i])){
                        counter[_names[i]] += 1;
                    }else{
                        counter.Add(_names[i], 1);
                    }
                }
            }
            var searched = new List<string>();
            foreach (var val in counter)
            {
                if (val.Value == pTags.Count){
                    searched.Add(val.Key);
                }
            }
            return searched;
        }
        public void Save(Action<List<string>> pSaveMethod)
        {
            pSaveMethod(this.ToListConvertTextLine());
        }
        private List<string> ToListConvertTextLine()
        {
            var sortKeyDict = new Dictionary<int, string>();
            for (var i = 0; i < _names.Count(); i++)
            {
                sortKeyDict.Add(i, _names[i]);
            }
            var sortedDict = sortKeyDict.OrderBy(o => o.Value);
            var sortedList = new List<string>();
            var beforeName = string.Empty;
            int sortedListIdx = -1;
            for (var i = 0; i < sortedDict.Count(); i++)
            {
                if (beforeName != _names[sortedDict.ElementAt(i).Key]){
                    sortedList.Add(_names[sortedDict.ElementAt(i).Key] + ":" + _tags[sortedDict.ElementAt(i).Key]);
                    sortedListIdx++;
                }else{
                    sortedList[sortedListIdx] += "," + _tags[sortedDict.ElementAt(i).Key];
                }
                beforeName = _names[sortedDict.ElementAt(i).Key];
            }
            return sortedList;
        }
        public void Read(List<string> lines)
        {
            foreach (var line in lines)
            {
                var textLine = line;
                if (textLine.StartsWith("//")){
                    continue;
                }
                int colonPos = textLine.IndexOf(":");
                if (colonPos == -1){
                    continue;
                }
                if (colonPos == textLine.Count() - 1){
                    continue;
                }
                var leftText = textLine.Substring(0, textLine.IndexOf(":"));
                var rightText = textLine.Substring(textLine.IndexOf(":") + 1);
                foreach (var val in rightText.Split(','))
                {
                    if (val.Trim() == string.Empty){
                        continue;
                    }
                    this.Add(leftText, val.Trim());
                }
            }
        }
        public Func<List<string>> GetAllTags { get; set; }
    }
}