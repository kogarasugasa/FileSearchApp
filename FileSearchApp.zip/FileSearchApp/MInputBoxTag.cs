using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FileSearchApp
{
    public static class MInputBoxTag
    {
        public static List<string> GetTags(List<string> pTags, List<string> pCheckedTags)
        {
            var vm = new VMInputBoxTag(pTags, pCheckedTags);
            Task.Run(() => Application.Run(new VInputBoxTag(vm))).Wait();
            return vm.CheckedTags;
        }
    }
    public class VMInputBoxTag
    {
        public VMInputBoxTag(List<string> pTags, List<string> pCheckedTags)
        {
            this.Tags = pTags;
            this.CheckedTags = new List<string>();
            this.Items = CreateItems();
            foreach (var val in this.Items)
            {
                val.Checked = pCheckedTags.Contains(val.Text);
            }
            this.ListViewColumnHeaders = CreateListViewColumnHeader(new List<int>());
        }
        ~VMInputBoxTag()
        {
            foreach (var val in this.Items)
            {
                if (val != null){
                    if (val.ImageList != null){
                        val.ImageList.Dispose();
                    }
                }
            }
            foreach (var val in this.ListViewColumnHeaders)
            {
                if (val != null){
                    if (val.ImageList != null){
                        val.ImageList.Dispose();
                    }
                }
            }
        }
        private List<ListViewItem> CreateItems()
        {
            var items = new List<ListViewItem>();
            foreach (var val in this.Tags)
            {
                var item = new ListViewItem(val.ToString());
                items.Add(item);
            }
            return items;
        }
        private ColumnHeader[] CreateListViewColumnHeader(List<int> pColumnWidths)
        {
            var header = new ColumnHeader[]
            {
                new ColumnHeader{Text = "TagName", Width = 200}
            };
            if (pColumnWidths.Count == 0)
            {
                return header;
            }
            int num = pColumnWidths.Count;
            num = Math.Min(header.Count(), num);
            num--;
            for (int i = 0; i < num; i++)
            {
                header[i].Width = pColumnWidths[i];
            }
            return header;
        }
        public ColumnHeader[] ListViewColumnHeaders { get; private set; }
        public List<ListViewItem> Items { get; private set; }
        public List<string> CheckedTags { get; set; }
        private List<string> Tags { get; set; }
    }
    public class VInputBoxTag : Form
    {
        private ListView _listView = new ListView();
        private Button _runSearchBtn = new Button();
        private VMInputBoxTag _vm;

        public VInputBoxTag(VMInputBoxTag pVMTagSearch)
        {
            _vm = pVMTagSearch;
            InitializeComponent();
            InitializeEventSet();
        }
        public void InitializeComponent()
        {
            this.Text = "履歴から検索";
            this.Width = 300;
            this.Height = 300;

            this.Controls.Add(_runSearchBtn);
            _runSearchBtn.Text = "検索";
            _runSearchBtn.Top = 9;
            _runSearchBtn.Left = 10;
            _runSearchBtn.Height = 21;
            _runSearchBtn.Width = 60;

            this.Controls.Add(_listView);
            _listView.Top = _runSearchBtn.Top + _runSearchBtn.Height + 5;
            _listView.Left = 10;
            _listView.Height = this.Height - _listView.Top - 50;
            _listView.Width = this.Width - 36;
            _listView.MultiSelect = false;
            _listView.AllowColumnReorder = true;
            _listView.FullRowSelect = true;
            _listView.Scrollable = true;
            _listView.GridLines = true;
            _listView.HideSelection = false;
            _listView.Sorting = SortOrder.None;
            _listView.View = View.Details;
            _listView.CheckBoxes = true;
            _listView.Columns.AddRange(_vm.ListViewColumnHeaders);
            _listView.Items.AddRange(_vm.Items.ToArray());
        }
        public void InitializeEventSet()
        {
            this.Load += new EventHandler((s, e) =>
            {
                this.Top = Cursor.Position.Y;
                this.Left = Cursor.Position.X;
            });
            this.FormClosed += new FormClosedEventHandler((s, e) =>
            {
                _vm.CheckedTags = _vm.Items.Where(val => val.Checked).Select(val => val.Text).ToList();
            });
            _runSearchBtn.Click += new EventHandler((s, e) =>
            {
                this.Close();
            });
            this.SizeChanged += new EventHandler((s, e) =>
            {
                _listView.Height = this.Height - _listView.Top - 50;
                _listView.Width = this.Width - 36;
            });
            _listView.ItemChecked += new ItemCheckedEventHandler((s, e) =>
            {
                var vmItems = _vm.Items.Where(val => val.Text == e.Item.Text);
                if (vmItems.Count() != 1)
                {
                    return;
                }
                vmItems.ElementAt(0).Checked = e.Item.Checked;
            });
        }
    }
}