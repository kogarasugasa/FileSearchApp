using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace FileSearchApp
{
    public class MAliasManager
    {
        private List<string> _names = new List<string>();
        private List<string> _alias = new List<string>();
        SortedKeyValue _index = new SortedKeyValue();
        public MAliasManager(){}
        public MAliasManager(Func<List<string>> pGetAliasesSettingsMethod)
        {
            this.Read(pGetAliasesSettingsMethod);
        }
        public void Add(string pFileName, string pAlias, bool pOverWrite)
        {
            if (pAlias.Length == 0){
                return;
            }
            int idx = _names.IndexOf(pFileName.ToLower());

            bool exists = idx != -1;
            if (exists){
                if (pOverWrite){
                    _alias[idx] = pAlias;
                    return;
                }else{
                    return;
                }
            }
            _index.Add(new IndexKeyValue(pFileName.ToLower(), pAlias));
            _names.Add(pFileName.ToLower());
            _alias.Add(pAlias);
        }
        public void Remove(string pFileName)
        {
            int idx = _names.IndexOf(pFileName.ToLower());
            if (idx == -1){
                return;
            }
            _names.RemoveAt(idx);
            _alias.RemoveAt(idx);
        }
        public string GetAlias(string pFileName)
        {
            int idx = _names.IndexOf(pFileName.ToLower());
            if (idx == -1){
                return string.Empty;
            }
            return _alias[idx];
        }
        public List<string> GetNamesFuzzy(string pFileNameFuzzy)
        {
            var matchNames = new List<string>();
            for (int i = 0; i < _alias.Count; i++)
            {
                if (MyTool.FuzzyContains(pFileNameFuzzy.ToLower(), _alias[i])){
                    matchNames.Add(_names[i]);
                }
            }
            return matchNames;
        }
        public void Save(Action<List<string>> pSaveMethod)
        {
            var textLines = new List<string>();
            for (int i = 0; i < _names.Count; i++)
            {
                textLines.Add(_names[i] + ":" + _alias[i]);
            }
            pSaveMethod(textLines);
        }
        public void Read(Func<List<string>> pReadMethod)
        {
            foreach (var line in pReadMethod())
            {
                var textLine = line;
                if (textLine.StartsWith("//")){
                    continue;
                }
                int colonPos = textLine.IndexOf(":");
                if (colonPos == -1){
                    continue;
                }
                if (colonPos == textLine.Count() - 1){
                    continue;
                }
                var leftText = textLine.Substring(0, textLine.IndexOf(":"));
                var rightText = textLine.Substring(textLine.IndexOf(":") + 1);
                this.Add(leftText, rightText, false);
            }
        }
    }
}