using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace FileSearchApp
{
    public partial class AppView
    {
        public void InitializeEventSet()
        {
            // ============================================================
            // = 説明：Viewからのイベント
            // ============================================================
            this.Load += new EventHandler((s, e) =>
            {
                this.Top = _viewModelFileSearchApp.WindowProperty.Top;
                this.Left = _viewModelFileSearchApp.WindowProperty.Left;
                this.Width = _viewModelFileSearchApp.WindowProperty.Width;
                this.Height = _viewModelFileSearchApp.WindowProperty.Height;
                this.Enabled = true;
            });
            this.Shown += new EventHandler((s, e) =>
            {
                _searchWordsTxtbox.Focus();
            });
            this.FormClosed += new FormClosedEventHandler((s, e) =>
            {
                var window = new SizePosition
                {
                    Top = this.Top,
                    Left = this.Left,
                    Width = this.Width,
                    Height = this.Height
                };
                _viewModelFileSearchApp.WindowProperty = window;
                this.Form_FormClosed(s, e);
            });
            this.SizeChanged += new EventHandler((s, e) =>
            {
                _searchWordsTxtbox.Width = this.Width - _searchWordsTxtbox.Left - 26;
                _listView.Height = this.Height - _listView.Top - 50;
                _listView.Width = this.Width - 36;
            });
            this.Move += new EventHandler((s, e) =>
            {
                if (!this.Enabled)
                {
                    return;
                }
                var win = new SizePosition()
                {
                    Top = this.Top,
                    Left = this.Left,
                    Width = this.Width,
                    Height = this.Height
                };
                _viewModelFileSearchApp.WindowProperty = win;
            });
            _optionBtn.Click += new EventHandler((s, e) =>
            {
                var checkd = _viewModelFileSearchApp.OptionMenuItems.Where(val => val.Checked).Select(val => val.Text);
                var newMenuItems = _createOptionMenuItems();
                foreach (var val in newMenuItems)
                {
                    if (checkd.Contains(val.Text))
                    {
                        val.Checked = true;
                    }
                }
                _viewModelFileSearchApp.OptionMenuItems.ForEach(val => val.Dispose());
                _viewModelFileSearchApp.OptionMenuItems.Clear();
                this.ContextMenuStrip.Items.Clear();

                _viewModelFileSearchApp.OptionMenuItems = newMenuItems;
                newMenuItems.ForEach(val => this.ContextMenuStrip.Items.Add(val));
                this.ContextMenuStrip.Show(this, _optionBtn.Left, _optionBtn.Top + _optionBtn.Height - 2);
            });
            _getClipBtn.Click += new EventHandler((s, e) =>
            {
                _searchWordsTxtbox.Text = _viewModelFileSearchApp.GetClip();
                _searchWordsTxtbox.Focus();
            });
            _runSearchBtn.Click += new EventHandler(async (s, e) =>
            {
                //System.GC.Collect();
                if (_viewModelFileSearchApp.IsSearching)
                {
                    _viewModelFileSearchApp.CancelSearch();
                    return;
                }
                _searchWordsTxtbox.Focus();
                await _viewModelFileSearchApp.StartSearch();
            });
            _aliasCheckBox.CheckedChanged += new EventHandler((s, e) =>
            {
                _viewModelListView.AliasEnabled = ((CheckBox)s).Checked;
                //表示を更新しるためにイベント「RetrieveVirtualItem」を起動する
                var updateIndeces = GetDisplayIndices();
                _viewModelListView.DisplayFileInfos.UpdateFileAlias(updateIndeces);
                _viewModelListView.DisplayFileInfos.UpdateFileSize(updateIndeces);
                if (updateIndeces.Count == 0){
                    return;
                }
                _listView.RedrawItems(updateIndeces.Min(), updateIndeces.Max(), false);
            });
            _searchWordsTxtbox.GotFocus += new EventHandler((s, e) =>
            {
                Task.Run(() =>
                {
                    Task.Delay(10).Wait();
                    _searchWordsTxtbox.SelectAll();
                });
            });
            _searchWordsTxtbox.TextChanged += new EventHandler((s, e) =>
            {
                _viewModelFileSearchApp.SearchWords = _searchWordsTxtbox.Text;
            });
            _searchWordsTxtbox.KeyDown += new KeyEventHandler((s, e) =>
            {
                if (e.KeyCode == Keys.PageDown)
                {
                    var path = MInputBox.GetText("");
                    _modelHistory.Remove(path);
                    return;
                }
            });
            _searchWordsTxtbox.KeyPress += new KeyPressEventHandler((s, e) =>
            {
                if (e.KeyChar != (char)Keys.Enter)
                {
                    return;
                }
                e.Handled = true;
                _searchWordsTxtbox.SelectAll();
                _runSearchBtn.PerformClick();
            });
            _listView.ItemSelectionChanged += new ListViewItemSelectionChangedEventHandler((s, e) =>
            {
                if (e.ItemIndex < 0){
                    return;
                }
                if (_viewModelListView.SelectionItem != null){
                    _viewModelListView.SelectionItem.BackColor = System.Drawing.Color.White;
                }
                _viewModelListView.SelectionIndex = e.ItemIndex;
                _viewModelListView.SelectionItem = e.Item;
                e.Item.Selected = false;
                e.Item.Focused = false;
                _listView.SelectedIndices.Clear();
            });
            _listView.KeyDown += new KeyEventHandler(async (s, e) =>
            {
                e.Handled = true;
                if (e.KeyCode == Keys.Down){
                    if (_viewModelListView.SelectionIndex >= _viewModelListView.DisplayFileInfos.Count - 1){
                        return;
                    }
                    int nextIdx = _viewModelListView.SelectionIndex + 1;
                    _listView.SelectedIndices.Add(nextIdx);
                    _listView.EnsureVisible(nextIdx);
                }
                if (e.KeyCode == Keys.Up){
                    if (_viewModelListView.SelectionIndex <= 0){
                        return;
                    }
                    int nextIdx = _viewModelListView.SelectionIndex - 1;
                    _listView.SelectedIndices.Add(nextIdx);
                    _listView.EnsureVisible(nextIdx);
                }
                if (e.KeyCode == Keys.Enter){
                    int idx = _viewModelListView.SelectionIndex;
                    if (idx == -1){
                        return;
                    }
                    await _viewModelListView.OpenSelectionItemAsync();
                }
            });
            _listView.RetrieveVirtualItem += new RetrieveVirtualItemEventHandler((s, e) =>
            {
                var info = _viewModelListView.GetExFileInfo(e.ItemIndex);
                e.Item = _viewModelListView.ConvToListViewItem(info, e.ItemIndex);
                if (e.ItemIndex == _viewModelListView.SelectionIndex){
                    e.Item.BackColor = System.Drawing.Color.SkyBlue;
                    e.Item.Selected = false;
                    e.Item.Focused = false;
                }else{
                    e.Item.BackColor = System.Drawing.Color.White;
                }
            });
            _listView.ColumnClick += new ColumnClickEventHandler((s, e) =>
            {
                _viewModelListView.SortListView(e.Column);
                _listView.VirtualListSize = 0;
                _listView.VirtualListSize = _viewModelListView.VirtualListSize;
            });
            _listView.DoubleClick += new EventHandler(async (s, e) =>
            {
                await _viewModelListView.OpenSelectionItemAsync();
            });
            _listView.MouseClick += new MouseEventHandler(async (s, e) =>
            {
                if (e.Button != MouseButtons.Right)
                {
                    return;
                }
                _viewModelListView.ListViewMenuItems.ForEach(val => val.Dispose());
                _viewModelListView.ListViewMenuItems.Clear();
                _listView.ContextMenuStrip.Items.Clear();

                var menuItems = _createListViewMenuItems();
                _viewModelListView.ListViewMenuItems = menuItems;
                menuItems.ForEach(val => _listView.ContextMenuStrip.Items.Add(val));
                ExFileInfo info = await _viewModelListView.GetExFileInfoAsync();
                var selectionItemTags = _modelTag.GetTags(info.FileName());
                foreach (var val in _viewModelListView.ListViewMenuItems)
                {
                    if (val.Name != "tag")
                    {
                        continue;
                    }
                    if (selectionItemTags.Contains(val.Text))
                    {
                        val.Checked = true;
                    }
                    else
                    {
                        val.Checked = false;
                    }
                }
            });
            _listView.ContextMenuStrip.Opening += new System.ComponentModel.CancelEventHandler((s, e) =>
            {
                if (_viewModelListView.SelectionIndex < 0)
                {
                    e.Cancel = true;
                    return;
                }

            });
            // ============================================================
            // = 説明：Modelからのイベント
            // ============================================================
            _msgReceiver.ModelMessageReceived += new EventHandler<ModelMessageReceivedEventArgs>((s, e) =>
            {
                Task.Run(() => ShowAddTagAliasForm(e.Value));
            });
            // ============================================================
            // = 説明：ViewModelからのイベント
            // ============================================================
            _viewModelListView.ViewModelListViewCursorChanged += new EventHandler<ViewModelListViewCursorChangedEventArgs>((s, e) =>
            {
                _listView.Cursor = e.Value;
            });
            _viewModelListView.ViewModelVirtualListSizeChanged += new EventHandler<ViewModelVirtualListSizeChangedEventArgs>((s, e) =>
            {
                _listView.VirtualListSize = e.Value;
                this.Text = _title + " : " + e.Value.ToString();
            });
            _viewModelListView.ViewModelOpenFileAlert += new EventHandler<AlertEventArgs>((s, e) =>
            {
                //_modelHistory.Remove(e.Value);
                MessageBox.Show("ファイルまたはフォルダーを開けませんでした");
            });
            _viewModelFileSearchApp.ViewModeRunCaptionChanged += new EventHandler<ViewModelRunCaptionChangedEventArgs>((s, e) =>
            {
                this.Invoke((MethodInvoker)delegate ()
                {
                    _runSearchBtn.Text = e.Value;
                });
            });
        }
        public void ShowAddTagAliasForm(string pFilePath)
        {
            var fileName = ExFileInfo.GetFileName(pFilePath);
            var alias = _modelAlias.GetAlias(fileName);
            var tags = _modelSettings.GetTagMS();
            var checkedTags = _modelTag.GetTags(fileName);
            var methodResult = MInputBoxTagAlias.GetTagAndAlias(pFilePath, alias, tags, checkedTags);
            if (!methodResult.Commited)
            {
                return;
            }
            var uniPath = MyNativeMethod.Function.Drive.GetUniversalName(pFilePath);
            var task = _modelHistory.TryAdd(uniPath);
            _modelAlias.Add(fileName, methodResult.Alias, false);
            foreach (var tag in methodResult.CheckedTags)
            {
                _modelTag.Add(fileName, tag);
            }
        }
        public List<int> GetDisplayIndices()
        {
            int rowHeight = 16; //1行あたりの高さ
            int headHeight = 28; //ヘッダなど、それ以外の高さ
            int displayRowsCnt = (_listView.Height - headHeight) / rowHeight + 5;
            if (_viewModelListView.DisplayFileInfos.LastReadIndex >= _viewModelListView.DisplayFileInfos.Count){
                return new List<int>();
            }
            if (_viewModelListView.DisplayFileInfos.Count == 0){
                return new List<int>();
            }
            var list = new List<int>();
            int start = _viewModelListView.DisplayFileInfos.LastReadIndex - displayRowsCnt;
            int end = _viewModelListView.DisplayFileInfos.LastReadIndex + displayRowsCnt;
            start = Math.Max(0, start);
            end = Math.Min(_viewModelListView.DisplayFileInfos.Count - 1, end);
            for (int i = start; i <= end; i++)
            {
                list.Add(i);
            }
            return list;
        }
        public void ShowHistoryMaintenance()
        {
            _viewModelDisHis.WindowProperty = _viewModelFileSearchApp.WindowProperty;
            Task.Run(() => Application.Run(new VDisabledHistory(_viewModelDisHis))).Wait();
            _viewModelListView.DisplayUpdate();
        }
    }
}