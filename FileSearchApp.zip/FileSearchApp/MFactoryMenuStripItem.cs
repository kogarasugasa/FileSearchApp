using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FileSearchApp
{
    public class MFactoryToolStripMenuItem
    {
        public MFactoryToolStripMenuItem()
        {

        }
        public List<ToolStripMenuItem> CreateOptionMenuItems(
            Action pOpenDirectorySettings,
            Action pOpenTagSettings,
            Action pOpenExcludeDirectorySettings,
            Action<Func<ExFileInfo, bool>> pApplyListViewFilter,
            Func<List<string>> pGetTagMs,
            Func<string, List<string>> pGetTags,
            Action pExport,
            Action pShowHisMent
            )
        {
            var menuItems = new List<ToolStripMenuItem>();
            var item = new ToolStripMenuItem("検索フォルダの設定");
            item.Click += new EventHandler((s, e) => pOpenDirectorySettings());
            menuItems.Add(item);
            item = new ToolStripMenuItem("除外フォルダの設定");
            item.Click += new EventHandler((s, e) => pOpenExcludeDirectorySettings());
            menuItems.Add(item);
            item = new ToolStripMenuItem("タグの設定");
            item.Click += new EventHandler((s, e) => pOpenTagSettings());
            menuItems.Add(item);
            item = new ToolStripMenuItem("CSVで出力");
            item.Click += new EventHandler((s, e) =>
            {
                pExport();
            });
            menuItems.Add(item);
            item = new ToolStripMenuItem("無効な履歴を修復");
            item.Click += new EventHandler((s, e) =>
            {
                pShowHisMent();
            });
            menuItems.Add(item);
            item = new ToolStripMenuItem("───選択解除───");
            item.Click += new EventHandler((s, e) =>
            {
                menuItems.ForEach(val => val.Checked = false);
                pApplyListViewFilter((info) => true);
            });
            menuItems.Add(item);
            var tags = pGetTagMs();
            foreach (var val in tags)
            {
                var menuItem = new ToolStripMenuItem(val);
                menuItem.Name = "tag";
                menuItem.Checked = false;
                menuItem.Click += new EventHandler((s, e) =>
                {
                    menuItem.Checked = !menuItem.Checked;
                    var optionCheckd = menuItems
                        .Where(val2 => val2.Checked & val2.Name == "tag")
                        .Select(val3 => val3.Text);
                    optionCheckd = new List<string>(optionCheckd);
                    Func<ExFileInfo, bool> TagFilter = (info) =>
                    {
                        var itemCheckd = pGetTags(info.FileName());
                        var matchs = optionCheckd.Where(val2 => itemCheckd.Contains(val2));
                        return matchs.Count() == optionCheckd.Count();
                    };
                    pApplyListViewFilter(TagFilter);
                });
                menuItems.Add(menuItem);
            }
            return menuItems;
        }
        public List<ToolStripMenuItem> CreateListViewMenuItems(
            Func<Task> pOpenSelection,
            Func<List<string>> pGetTagMs,
            Func<Task<ExFileInfo>> pGetFileInfo,
            Action<string, string> pAddTag,
            Action<string, string> pRemoveTag,
            Action<string, string, bool> pAddAlias
            )
        {
            var menuItems = new List<ToolStripMenuItem>();
            var item = new ToolStripMenuItem("フォルダを開く");
            item.Click += new EventHandler(async (s, e) =>
            {
                await pOpenSelection();
            });
            menuItems.Add(item);
            item = new ToolStripMenuItem("別名を追加");
            item.Click += new EventHandler(async (s, e) =>
            {
                var info = await pGetFileInfo();
                var alias = MInputBox.GetText(info.Alias);
                if (alias.Trim() == string.Empty){
                    return;
                }
                pAddAlias(info.FileName(), alias,true);
                info.Alias = alias;
            });
            menuItems.Add(item);
            menuItems.Add(new ToolStripMenuItem("────────"));
            var tags = pGetTagMs();
            foreach (var val in tags)
            {
                var menuItem = new ToolStripMenuItem(val);
                menuItem.Name = "tag";
                menuItem.Checked = false;
                menuItem.Click += new EventHandler(async (s, e) =>
                {
                    menuItem.Checked = !menuItem.Checked;
                    var info = await pGetFileInfo();
                    var fileName = info.FileName();
                    if (menuItem.Checked){
                        pAddTag(fileName, menuItem.Text);
                    }else{
                        pRemoveTag(fileName, menuItem.Text);
                    }
                });
                menuItems.Add(menuItem);
            }
            return menuItems;
        }
    }
}