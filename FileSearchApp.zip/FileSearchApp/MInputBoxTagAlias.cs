using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FileSearchApp
{
    public static class MInputBoxTagAlias
    {
        public static GetTagAndAliasResult GetTagAndAlias(string pFilePath, string pAlias, List<string> pTags, List<string> pCheckedTags)
        {
            var fileName = ExFileInfo.GetFileName(pFilePath);
            var vm = new VMInputBoxTagAlias(fileName, pAlias, pTags, pCheckedTags);
            Task.Run(() => Application.Run(new VInputBoxTagAlias(vm))).Wait();
            var result = new GetTagAndAliasResult()
            {
                Commited = vm.Commited,
                CheckedTags = vm.CheckedTags,
                Alias = vm.Alias
            };
            return result;
        }
        public class GetTagAndAliasResult
        {
            public bool Commited = false;
            public List<string> CheckedTags = new List<string>();
            public string Alias = string.Empty;
        }
    }
    public class VMInputBoxTagAlias
    {
        public VMInputBoxTagAlias(string pFileName, string pAlias, List<string> pTags, List<string> pCheckedTags)
        {
            this.FileName = pFileName;
            this.Alias = pAlias;
            this.CheckedTags = new List<string>();
            this.Top = Cursor.Position.Y - 150;
            this.Left = Cursor.Position.X - 200;
            this.Items = CreateItems(pTags, pCheckedTags);
            this.ListViewColumnHeaders = CreateListViewColumnHeader(new List<int>());
        }
        ~VMInputBoxTagAlias()
        {
            foreach (var val in this.ListViewColumnHeaders)
            {
                if (val != null){
                    val.Dispose();
                }
            }
            foreach (var val in this.Items)
            {
                if (val != null){
                    if (val.ImageList != null){
                        val.ImageList.Dispose();
                    }
                }
            }
        }
        public void Commit()
        {
            this.Commited = true;
        }
        public List<ListViewItem> CreateItems(List<string> pTags, List<string> pCheckedTags)
        {
            var items = new List<ListViewItem>();
            foreach (var val in pTags)
            {
                var item = new ListViewItem(val.ToString());
                item.Checked = pCheckedTags.Contains(val);
                items.Add(item);
            }
            return items;
        }
        public ColumnHeader[] CreateListViewColumnHeader(List<int> pColumnWidths)
        {
            var header = new ColumnHeader[]
            {
                new ColumnHeader{Text = "TagName", Width = 200}
            };
            if (pColumnWidths.Count == 0)
            {
                return header;
            }
            int num = pColumnWidths.Count;
            num = Math.Min(header.Count(), num);
            num--;
            for (int i = 0; i < num; i++)
            {
                header[i].Width = pColumnWidths[i];
            }
            return header;
        }
        public bool Commited { get; private set; }
        public ColumnHeader[] ListViewColumnHeaders { get; private set; }
        public List<ListViewItem> Items { get; private set; }
        public int Top { get; set; }
        public int Left { get; set; }
        public string Alias { get; set; }
        public string FileName { get; set; }
        public List<string> CheckedTags { get; set; }
    }
    public class VInputBoxTagAlias : Form
    {
        private ListView _listView = new ListView();
        private Button _runSearchBtn = new Button();
        private TextBox _aliasTextBox = new TextBox();
        private TextBox _fileNameTextBox = new TextBox();
        private Label _aliasLabel = new Label();

        public VInputBoxTagAlias(VMInputBoxTagAlias pVMAddWindow)
        {
            this.ViewModel = pVMAddWindow;
            InitializeComponent();
            InitializeEventSet();
        }
        public void InitializeComponent()
        {
            this.Width = 700;
            this.Height = 300;
            this.Text = "add Alias and Tag";

            this.Controls.Add(_fileNameTextBox);
            _fileNameTextBox.Top = 9;
            _fileNameTextBox.Left = 10;
            _fileNameTextBox.Width = this.Width - 36;
            _fileNameTextBox.Text = this.ViewModel.FileName;
            _fileNameTextBox.Enabled = false;

            this.Controls.Add(_runSearchBtn);
            _runSearchBtn.Text = "追加";
            _runSearchBtn.Top = _fileNameTextBox.Top + _fileNameTextBox.Height + 5;
            _runSearchBtn.Left = 10;
            _runSearchBtn.Height = 21;
            _runSearchBtn.Width = 50;

            this.Controls.Add(_aliasLabel);
            _aliasLabel.Top = _fileNameTextBox.Top + _fileNameTextBox.Height + 5;
            _aliasLabel.Left = _runSearchBtn.Left + _runSearchBtn.Width + 5;
            _aliasLabel.Width = 35;
            _aliasLabel.Height = _runSearchBtn.Height;
            _aliasLabel.Text = "Alias";
            _aliasLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            this.Controls.Add(_aliasTextBox);
            _aliasTextBox.Top = _fileNameTextBox.Top + _fileNameTextBox.Height + 5;
            _aliasTextBox.Left = _aliasLabel.Left + _aliasLabel.Width + 5;
            _aliasTextBox.Width = this.Width - _aliasTextBox.Left - 26;

            this.Controls.Add(_listView);
            _listView.Top = _runSearchBtn.Top + _runSearchBtn.Height + 5;
            _listView.Left = 10;
            _listView.Height = this.Height - _listView.Top - 50;
            _listView.Width = this.Width - 36;
            _listView.MultiSelect = false;
            _listView.AllowColumnReorder = true;
            _listView.FullRowSelect = true;
            _listView.Scrollable = true;
            _listView.GridLines = true;
            _listView.HideSelection = false;
            _listView.Sorting = SortOrder.None;
            _listView.View = View.Details;
            _listView.CheckBoxes = true;
            _listView.Columns.AddRange(this.ViewModel.ListViewColumnHeaders);
            _listView.Items.AddRange(this.ViewModel.Items.ToArray());
        }
        public void InitializeEventSet()
        {
            this.Load += new EventHandler((s, e) =>
            {
                this.Top = this.ViewModel.Top;
                this.Left = this.ViewModel.Left;
            });
            this.Shown += new EventHandler((s, e) =>
            {
                this.TopMost = true;
                Task.Delay(100).Wait(); //ちょい待つとフォーカスを取得できることが多い
                this.Focus();
                _aliasTextBox.Focus();
                _aliasTextBox.Text = this.ViewModel.Alias;
                _fileNameTextBox.Text = this.ViewModel.FileName;
            });
            this.FormClosed += new FormClosedEventHandler((s, e) =>
            {
                this.ViewModel.CheckedTags = this.ViewModel.Items.Where(val => val.Checked).Select(val => val.Text).ToList();
            });
            _runSearchBtn.Click += new EventHandler((s, e) =>
            {
                this.ViewModel.Alias = _aliasTextBox.Text;
                this.ViewModel.Commit();
                this.Close();
            });
            this.SizeChanged += new EventHandler((s, e) =>
            {
                _listView.Height = this.Height - _listView.Top - 50;
                _listView.Width = this.Width - 36;
                _fileNameTextBox.Width = this.Width - 36;
                _aliasTextBox.Width = this.Width - _aliasTextBox.Left - 26;
            });
        }
        public VMInputBoxTagAlias ViewModel { get; set; }
    }
}