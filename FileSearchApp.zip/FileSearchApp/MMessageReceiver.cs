using System;
using System.Linq;
using System.IO.Pipes;
using System.Threading;
using System.Threading.Tasks;

namespace FileSearchApp
{
    public class MMessageReceiver
    {
        CancellationTokenSource _cts = new CancellationTokenSource();
        Task _recieveTask = Task.Delay(10);
        public MMessageReceiver(bool pMessageRecieverStart)
        {
            if (!pMessageRecieverStart)
            {
                return;
            }
            _recieveTask = StartRecieverAsync(_cts.Token);
        }
        ~MMessageReceiver()
        {
            _cts.Cancel();
            _cts.Dispose();
            while (!_recieveTask.IsCompleted)
            {
                Task.Delay(50).Wait();
            }
        }
        public async Task StartRecieverAsync(CancellationToken cancellationToken)
        {
            string pipeName = FileSearchAppPipeName.Value;
            while (true)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    break;
                }
                try
                {
                    using (var pipeServer = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 1))
                    {
                        // クライアントの接続待ち
                        await pipeServer.WaitForConnectionAsync(cancellationToken);
                        StreamString ss = new StreamString(pipeServer);

                        // 受信待ち
                        var read = ss.ReadString();

                        // 受信したら応答を送信
                        ss.WriteString("OK");
                        ModelMessageReceived.Invoke(this, new ModelMessageReceivedEventArgs(read));
                        pipeServer.Close();
                    }
                }
                catch (OverflowException ex)
                {
                    // クライアントが切断
                    Console.WriteLine(ex.Message);
                }
            }
        }
        public event EventHandler<ModelMessageReceivedEventArgs> ModelMessageReceived = delegate { };
    }
}