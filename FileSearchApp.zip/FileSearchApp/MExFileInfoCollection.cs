using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FileSearchApp
{
    public class MExFileInfoCollection
    {
        Dictionary<int, ExFileInfo> _allFileInfos = new Dictionary<int, ExFileInfo>();
        Dictionary<int, ExFileInfo> _publicFileInfos;
        List<ExFileInfo> _bufferFileInfos = new List<ExFileInfo>(); //ソート、フィルタ中に追加出来るようにするため
        List<string> _duplicateCheckList = new List<string>();
        TaskCancellationTokenSourceCollection _cancelableTask = new TaskCancellationTokenSourceCollection();
        bool _isBufferUsed = false;
        public static Func<ExFileInfo, bool> DefaultFilter = (info) => true;
        object _lock = new object();
        public MExFileInfoCollection()
        {
            _publicFileInfos = _allFileInfos;
            _filter = val => true;
            this.GetAliasMethod = str => string.Empty;
        }
        ~MExFileInfoCollection()
        {
            _cancelableTask.CancelAll();
        }
        public void Clear()
        {
            lock (_lock)
            {
                _cancelableTask.CancelAll();
                _allFileInfos.Clear();
                _publicFileInfos.Clear();
                _bufferFileInfos.Clear();
                _duplicateCheckList.Clear();
                //_publicFileInfos = _allFileInfos;
            }
        }
        public bool TryAddNotDuplicate(ExFileInfo pInfo)
        {
            lock (_lock)
            {
                pInfo.Alias = this.GetAliasMethod(pInfo.FileName());
                //重複したら追加しない
                int idx = _duplicateCheckList.IndexOf(pInfo.FilePath);
                if (idx >= 0){
                    //Sizeの更新があればする
                    if (pInfo.Size == 0){
                        return false;
                    }
                    if (idx >= _allFileInfos.Count){
                        //_allFileInfosの範囲外
                        idx -= _allFileInfos.Count;
                        _bufferFileInfos[idx].Size = pInfo.Size;
                    }else{
                        _allFileInfos[idx].Size = pInfo.Size;
                    }
                    return false;
                }
                _duplicateCheckList.Add(pInfo.FilePath);
                if (_isBufferUsed){
                    _bufferFileInfos.Add(pInfo);
                }
                _allFileInfos.Add(_allFileInfos.Count, pInfo);
                if (_publicFileInfos != _allFileInfos & this.Filter(pInfo)){
                    _publicFileInfos.Add(_publicFileInfos.Count, pInfo);
                }
            }
            return true;
        }
        public ExFileInfo ElementAt(int pIndex)
        {
            lock (_lock)
            {
                return ElementAtDirtyRead(pIndex);
            }
        }
        public ExFileInfo ElementAtDirtyRead(int pIndex)
        {
            Interlocked.Exchange(ref _lastReadIndex, pIndex);
            ExFileInfo info;
            if (_publicFileInfos.TryGetValue(pIndex, out info))
            {
                return info;
            }
            var errInfo = new ExFileInfo();
            errInfo.FilePath = "Faild:\\MExFileInfoList_ElementAt_" + pIndex.ToString();
            return errInfo;
        }
        public void UpdateFileSize(List<int> pIndices)
        {
            _cancelableTask.CancelAll();
            Action<CancellationToken> task = (ct) =>
            {
                lock (_lock)
                {
                    foreach (var val in pIndices)
                    {
                        var exInfo = ElementAt(val);
                        if (exInfo.Size != 0){
                            continue;
                        }
                        if (!System.IO.File.Exists(exInfo.FilePath)){
                            exInfo.Invalided = true;
                            continue;
                        }
                        var info = new System.IO.FileInfo(exInfo.FilePath);
                        exInfo.Size = info.Length;
                        if (ct.IsCancellationRequested){
                            break;
                        }
                    }
                }
            };
            int id = _cancelableTask.Add(task);
            _cancelableTask.Wait(id);
        }
        public void UpdateFileAlias(List<int> pIndices)
        {
            _cancelableTask.CancelAll();
            Action<CancellationToken> task = (ct) =>
            {
                lock (_lock)
                {
                    foreach (var val in pIndices)
                    {
                        var exInfo = ElementAt(val);
                        exInfo.Alias = GetAliasMethod(exInfo.FileName());
                        if (ct.IsCancellationRequested){
                            break;
                        }
                    }
                }
            };
            int id = _cancelableTask.Add(task);
            _cancelableTask.Wait(id);
        }
        public void Sort(string pColumnText, SortOrder pSortOrder)
        {
            List<ExFileInfo> sorted;
            lock (_lock)
            {
                _isBufferUsed = true;
                sorted = _publicFileInfos.Values.ToList();
            }
            switch (pColumnText)
            {
                case "Size":
                    sorted.Sort((val1,val2) =>
                    {
                        ExFileInfo[] vals = {val2,val1,val2};
                        var i = Math.Abs(pSortOrder.CompareTo(SortOrder.Descending));
                        return ((long)vals[i].Size).CompareTo((long)vals[i + 1].Size);
                    });
                    break;
                case "Path":
                    sorted.Sort((val1,val2) =>
                    {
                        ExFileInfo[] vals = {val2,val1,val2};
                        var i = Math.Abs(pSortOrder.CompareTo(SortOrder.Descending));
                        return vals[i].FilePath.CompareTo(vals[i + 1].FilePath);
                    });
                    break;
                case "FileName":
                    sorted.Sort((val1,val2) =>
                    {
                        ExFileInfo[] vals = {val2,val1,val2};
                        var i = Math.Abs(pSortOrder.CompareTo(SortOrder.Descending));
                        return vals[i].FileName().CompareTo(vals[i + 1].FileName());
                    });
                    break;
                case "Extension":
                    sorted.Sort((val1,val2) =>
                    {
                        ExFileInfo[] vals = {val2,val1,val2};
                        var i = Math.Abs(pSortOrder.CompareTo(SortOrder.Descending));
                        return vals[i].Extension().CompareTo(vals[i + 1].Extension());
                    });
                    break;
                default:
                    break;
            }
            int newKey = 0;
            var sortedDict = sorted.ToDictionary(val => newKey++);
            lock (_lock)
            {
                _isBufferUsed = false;
                foreach (var val in _bufferFileInfos)
                {
                    sortedDict.Add(sortedDict.Count, val);
                }
                _publicFileInfos = sortedDict;
            }
        }
        public void ApplyFilter(Func<ExFileInfo, bool> pFilter)
        {
            this.Filter = pFilter;
        }
        public void RemoveFilter()
        {
            this.Filter = DefaultFilter;
        }
        private Func<ExFileInfo, bool> _filter;
        public Func<ExFileInfo, bool> Filter
        {
            get{ return _filter; }
            set
            {
                if (this.Filter == DefaultFilter){
                    _filter = (info) => {return true; };
                    _publicFileInfos = _allFileInfos;
                    return;
                }
                Dictionary<int, ExFileInfo> clone;
                lock (_lock)
                {
                    _filter = value;
                    _isBufferUsed = true;
                    clone = new Dictionary<int, ExFileInfo>(_allFileInfos);
                }
                var filtered = new Dictionary<int, ExFileInfo>();
                foreach (var val in clone)
                {
                    if (this.Filter(val.Value)){
                        filtered.Add(filtered.Count, val.Value);
                    }
                }
                lock (_lock)
                {
                    _isBufferUsed = false;
                    foreach (var val in _bufferFileInfos)
                    {
                        if (this.Filter(val)){
                            filtered.Add(filtered.Count, val);
                        }
                    }
                    _publicFileInfos = filtered;
                }
            }
        }
        long _lastReadIndex = 0;
        public int LastReadIndex
        {
            get
            {
                return (int)Interlocked.Read(ref _lastReadIndex);
            }
        }
        public int Count
        {
            get
            {
                lock (_lock)
                {
                    return _publicFileInfos.Count;
                }
            }
        }
        public Func<string, string> GetAliasMethod;
    }
}
