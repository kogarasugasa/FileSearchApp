using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Windows.Forms.VisualStyles;
using System.Threading;
using System.Linq;
using System.IO;
using System.IO.Pipes;
using System.Security.Principal;


namespace FileSearchApp
{
    public class FileSearchApp
    {
        [DllImport("kernel32.dll")]
        static extern bool FreeConsole();
        [STAThread]
        public static void Main(string[] args)
        {
            //Test.Test005();
            //return;
            MyNativeMethod.Function.Screen.SetProcessDPIAware(); // 最初に呼び出す
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            bool createdNew;
            using (var mutex = new Mutex(true, "PreventMultipleLaunchFileSearchApp", out createdNew))
            {
                if (!createdNew)
                {
                    //引数を送信
                    if (args.Count() != 0)
                    {
                        SendArgs(args[0]);
                    }
                    return;
                }
                try
                {
                    Application.Run(new AppView(args));
                }
                finally
                {
                    mutex.ReleaseMutex();
                }
            }
        }
        public static void SendArgs(string pMessage)
        {
            string pipeName = FileSearchAppPipeName.Value;
            try
            {
                using (var pipeClient = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut, PipeOptions.None, TokenImpersonationLevel.Impersonation))
                {
                    pipeClient.Connect();
                    var ss = new StreamString(pipeClient);

                    // 入力された文字列を送信する
                    var write = ss.WriteString(pMessage);
                    // 応答待ち
                    var read = ss.ReadString();
                }
            }
            catch (OverflowException ofex)
            {
                Console.WriteLine(ofex.Message);
            }
            catch (IOException ioe)
            {
                // 送信失敗
                Console.WriteLine(ioe.Message);
            }
        }
    }
}