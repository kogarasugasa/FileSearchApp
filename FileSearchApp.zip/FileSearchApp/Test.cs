using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Reflection;
using System.Windows.Forms;

namespace FileSearchApp
{
    public static class AppTest
    {
        public static void Main(string[] args)
        {
            var testMsg = new List<string>();
            Action<string> fn = str => testMsg.Add(str);
            //以下テストインスタンス記述部
            new MHistorySearcherTest().TestAll().ForEach(fn);
            new MExFileInfoCollectionTest().TestAll().ForEach(fn);
            new MAliasManagerTest().TestAll().ForEach(fn);
            new MTagManagerTest().TestAll().ForEach(fn);
            new MyToolTest().TestAll().ForEach(fn);
            //以下結果表示部
            Console.Clear();
            testMsg.ForEach(msg => Console.WriteLine(msg));
            Console.WriteLine("-   --   --   --   --   --   --   -");
            Console.WriteLine("Test completed.");
            Console.WriteLine("After confirming the message, press enter to exit.");
            Console.ReadLine();
        }
    }
    public class MHistorySearcherTest : TestBase
    {
        public override List<string> TestAll()
        {
            return base.TestAll<MHistorySearcherTest>();
        }
        public List<string> TestConstructor()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 15:52");
                var his = new MHistorySearcher();
                if (his.GetAlias("1") != string.Empty){
                    return msg;
                }
                msg.Add("2024/05/31 15:54");
                if (his.GetExcludeDirectory().Count != 0){
                    return msg;
                }
                msg.Add("2024/05/31 16:06");
                if (his.SearchWords.Count != 0){
                    return msg;
                }
                msg.Add("2024/05/31 16:08");
                if (his.RunActionWhenFileFound.Count != 0){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestRead()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 16:10");
                var his = new MHistorySearcher();
                Func<List<string>> read = () => new List<string>(){
                    @"C:\test\4.txt",
                    @"C:\test\5.txt",
                };
                his.Read(read);
                var ct = new CancellationToken();
                var _lock = new object();
                Action errAction = () => { throw new Exception("timeout"); };
                var errThrowTask = Task.Run(() =>
                {
                    Task.Delay(1000).Wait();
                    lock (_lock) { errAction(); }
                });
                var result = his.GetResultAndRunSearch(new List<string>() { "*" }, ct);
                lock (_lock) { errAction = () => Task.Delay(1); }
                msg.Add("2024/05/31 16:11");
                if (result.Count() != 2){
                    return msg;
                }
                msg.Add("2024/05/31 16:12");
                if (result.ElementAt(0).FilePath != @"C:\test\4.txt"){
                    return msg;
                }
                if (result.ElementAt(1).FilePath != @"C:\test\5.txt"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestTryAdd()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 16:13");
                var his = new MHistorySearcher();
                his.TryAdd(@"C:\test\5.txt");
                his.TryAdd(@"C:\test\6.txt");
                his.TryAdd(@"C:\test\3.txt");
                his.TryAdd(@"C:\test\4.txt");
                his.TryAdd(@"C:\test\2.txt");
                his.TryAdd(@"C:\test\7.txt");
                his.TryAdd(@"C:\test\3.txt");
                var ct = new CancellationToken();
                var _lock = new object();
                Action errAction = () => { throw new Exception("timeout"); };
                var errThrowTask = Task.Run(() =>
                {
                    Task.Delay(1000).Wait();
                    lock (_lock) { errAction(); }
                });
                var result = his.GetResultAndRunSearch(new List<string>() { "*" }, ct);
                lock (_lock) { errAction = () => Task.Delay(1); }
                msg.Add("2024/05/31 16:47");
                if (result.Count() != 6){
                    return msg;
                }
                msg.Add("2024/05/31 16:51");
                if (result.ElementAt(0).FilePath != @"C:\test\2.txt"){
                    return msg;
                }
                if (result.ElementAt(1).FilePath != @"C:\test\3.txt"){
                    return msg;
                }
                if (result.ElementAt(2).FilePath != @"C:\test\4.txt"){
                    return msg;
                }
                if (result.ElementAt(3).FilePath != @"C:\test\5.txt"){
                    return msg;
                }
                if (result.ElementAt(4).FilePath != @"C:\test\6.txt"){
                    return msg;
                }
                if (result.ElementAt(5).FilePath != @"C:\test\7.txt"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestAddBuffer()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 16:56");
                var his = new MHistorySearcher();
                his.AddToBuffer(@"C:\test\5.txt");
                his.AddToBuffer(@"C:\test\6.txt");
                his.AddToBuffer(@"C:\test\3.txt");
                Task.Delay(2050).Wait(); // バッファのフラッシュを待つ
                var ct = new CancellationToken();
                var _lock = new object();
                Action errAction = () => { throw new Exception("timeout"); };
                var errThrowTask = Task.Run(() =>
                {
                    Task.Delay(1000).Wait();
                    lock (_lock) { errAction(); }
                });
                var result = his.GetResultAndRunSearch(new List<string>() { "*" }, ct);
                lock (_lock) { errAction = () => Task.Delay(1); }
                msg.Add("2024/05/31 16:47");
                if (result.Count() != 3){
                    return msg;
                }
                msg.Add("2024/05/31 16:51");
                if (result.ElementAt(0).FilePath != @"C:\test\3.txt"){
                    return msg;
                }
                if (result.ElementAt(1).FilePath != @"C:\test\5.txt"){
                    return msg;
                }
                if (result.ElementAt(2).FilePath != @"C:\test\6.txt"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestRemove()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 16:13");
                var his = new MHistorySearcher();
                his.TryAdd(@"C:\test\5.txt");
                his.TryAdd(@"C:\test\6.txt");
                his.TryAdd(@"C:\test\3.txt");
                his.TryAdd(@"C:\test\4.txt");
                his.TryAdd(@"C:\test\2.txt");
                his.TryAdd(@"C:\test\7.txt");
                his.Remove(@"C:\test\4.txt");
                var ct = new CancellationToken();
                var _lock = new object();
                Action errAction = () => { throw new Exception("timeout"); };
                var errThrowTask = Task.Run(() =>
                {
                    Task.Delay(1000).Wait();
                    lock (_lock) { errAction(); }
                });
                var result = his.GetResultAndRunSearch(new List<string>() { "*" }, ct);
                lock (_lock) { errAction = () => Task.Delay(1); }
                msg.Add("2024/05/31 16:47");
                if (result.Count() != 5){
                    return msg;
                }
                msg.Add("2024/05/31 16:51");
                if (result.ElementAt(0).FilePath != @"C:\test\2.txt"){
                    return msg;
                }
                if (result.ElementAt(1).FilePath != @"C:\test\3.txt"){
                    return msg;
                }
                if (result.ElementAt(2).FilePath != @"C:\test\5.txt"){
                    return msg;
                }
                if (result.ElementAt(3).FilePath != @"C:\test\6.txt"){
                    return msg;
                }
                if (result.ElementAt(4).FilePath != @"C:\test\7.txt"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestPathMaintenance()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 17:53");
                var filePath = Path.GetTempFileName();
                var his = new MHistorySearcher();
                his.TryAdd(filePath);
                his.TryAdd(@"C:\test\6.txt");
                his.PathMaintenance(5);
                var ct = new CancellationToken();
                var _lock = new object();
                Action errAction = () => { throw new Exception("timeout"); };
                var errThrowTask = Task.Run(() =>
                {
                    Task.Delay(1000).Wait();
                    lock (_lock) { errAction(); }
                });
                var result = his.GetResultAndRunSearch(new List<string>() { "*" }, ct);
                lock (_lock) { errAction = () => Task.Delay(1); }
                msg.Add("2024/05/31 17:54");
                if (result.Count() != 1){
                    return msg;
                }
                msg.Add("2024/05/31 17:55");
                if (result.ElementAt(0).FilePath != filePath){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestStartSearchAsync()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 18:01");
                var his = new MHistorySearcher();
                his.TryAdd(@"C:\test\7.txt");
                his.TryAdd(@"C:\test\4.txt");
                his.TryAdd(@"C:\test\6.txt");
                his.TryAdd(@"C:\test\3.txt");
                his.TryAdd(@"C:\test\2.txt");
                his.TryAdd(@"C:\test\5.txt");

                var infos = new List<ExFileInfo>();
                his.SearchWords = new List<string>(){"5","6"};
                his.RunActionWhenFileFound.Add((info) => infos.Add(info));

                var ct = new CancellationToken();
                var _lock = new object();
                Action errAction = () => { throw new Exception("timeout"); };
                var errThrowTask = Task.Run(() =>
                {
                    Task.Delay(1000).Wait();
                    lock (_lock) { errAction(); }
                });
                var task = his.StartSearchAsync(ct);
                lock (_lock) { errAction = () => Task.Delay(1); }
                while (!task.IsCompleted) { Task.Delay(100).Wait(); }

                msg.Add("2024/05/31 18:04");
                if (infos.Count != 2){
                    return msg;
                }
                msg.Add("2024/05/31 18:24");
                var paths = infos.ToList().Select(val => val.FilePath);
                if (!paths.Contains(@"C:\test\5.txt")){
                    return msg;
                }
                msg.Add("2024/05/31 18:26");
                if (!paths.Contains(@"C:\test\6.txt")){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
    }
    public class MExFileInfoCollectionTest : TestBase
    {
        public override List<string> TestAll()
        {
            return base.TestAll<MExFileInfoCollectionTest>();
        }
        public List<string> TestTryAdd()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 11:27");
                var ar = new MExFileInfoCollection();
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\1.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\2.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\3.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\4.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\5.c"));
                msg.Add("2024/06/03 11:28");
                if (ar.Count != 5){
                    return msg;
                }
                msg.Add("2024/06/03 11:29");
                var vl1 = ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\3.c"));
                if (vl1 == true){
                    return msg;
                }
                msg.Add("2024/06/03 11:30");
                var vl2 = ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\6.c"));
                if (vl2 == false){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestElementAt()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 11:33");
                var ar = new MExFileInfoCollection();
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\1.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\3.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\2.c"));
                msg.Add("2024/06/03 11:37");
                if (ar.ElementAt(0).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                if (ar.ElementAt(1).FilePath != @"c:\test\3.c"){
                    return msg;
                }
                if (ar.ElementAt(2).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestClear()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 11:38");
                var ar = new MExFileInfoCollection();
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\1.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\3.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\2.c"));
                ar.Clear();
                msg.Add("2024/06/03 11:39");
                if (ar.Count != 0){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestSort()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 11:40");
                var ar = new MExFileInfoCollection();
                var i1 = new ExFileInfo(){FilePath = @"c:\test\1.c", Size = 1000};
                var i2 = new ExFileInfo(){FilePath = @"c:\test\3.c", Size = 1500};
                var i3 = new ExFileInfo(){FilePath = @"c:\test\2.c", Size = 10};
                var i4 = new ExFileInfo(){FilePath = @"c:\test1\2.c", Size = 2100000};
                var i5 = new ExFileInfo(){FilePath = @"c:\test2\1.c", Size = 1450};
                ar.TryAddNotDuplicate(i1);
                ar.TryAddNotDuplicate(i2);
                ar.TryAddNotDuplicate(i3);
                ar.TryAddNotDuplicate(i4);
                ar.TryAddNotDuplicate(i5);
                ar.Sort("Path", System.Windows.Forms.SortOrder.Ascending);
                msg.Add("2024/06/03 11:42");
                if (ar.ElementAt(0).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                if (ar.ElementAt(1).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                if (ar.ElementAt(2).FilePath != @"c:\test\3.c"){
                    return msg;
                }
                if (ar.ElementAt(3).FilePath != @"c:\test1\2.c"){
                    return msg;
                }
                if (ar.ElementAt(4).FilePath != @"c:\test2\1.c"){
                    return msg;
                }
                ar.Sort("Path", System.Windows.Forms.SortOrder.Descending);
                msg.Add("2024/06/03 11:47");
                if (ar.ElementAt(0).FilePath != @"c:\test2\1.c"){
                    return msg;
                }
                if (ar.ElementAt(1).FilePath != @"c:\test1\2.c"){
                    return msg;
                }
                if (ar.ElementAt(2).FilePath != @"c:\test\3.c"){
                    return msg;
                }
                if (ar.ElementAt(3).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                if (ar.ElementAt(4).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                ar.Sort("FileName", System.Windows.Forms.SortOrder.Ascending);
                msg.Add("2024/06/03 11:48");
                if (ar.ElementAt(0).FilePath != @"c:\test2\1.c" &
                    ar.ElementAt(0).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                if (ar.ElementAt(1).FilePath != @"c:\test2\1.c" &
                    ar.ElementAt(1).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                if (ar.ElementAt(2).FilePath != @"c:\test1\2.c" &
                    ar.ElementAt(2).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                if (ar.ElementAt(3).FilePath != @"c:\test1\2.c" &
                    ar.ElementAt(3).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                if (ar.ElementAt(4).FilePath != @"c:\test\3.c"){
                    return msg;
                }
                ar.Sort("Size", System.Windows.Forms.SortOrder.Ascending);
                msg.Add("2024/06/03 11:50");
                if (ar.ElementAt(0).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                if (ar.ElementAt(1).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                if (ar.ElementAt(2).FilePath != @"c:\test2\1.c"){
                    return msg;
                }
                if (ar.ElementAt(3).FilePath != @"c:\test\3.c"){
                    return msg;
                }
                if (ar.ElementAt(4).FilePath != @"c:\test1\2.c"){
                    return msg;
                }
                ar.Sort("Size", System.Windows.Forms.SortOrder.Descending);
                msg.Add("2024/06/03 11:58");
                if (ar.ElementAt(0).FilePath != @"c:\test1\2.c"){
                    return msg;
                }
                if (ar.ElementAt(1).FilePath != @"c:\test\3.c"){
                    return msg;
                }
                if (ar.ElementAt(2).FilePath != @"c:\test2\1.c"){
                    return msg;
                }
                if (ar.ElementAt(3).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                if (ar.ElementAt(4).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestUpdateFileSize()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 14:05");
                var ar = new MExFileInfoCollection();
                var path1 = Path.GetTempFileName();
                var path2 = Path.GetTempFileName();
                File.AppendAllText(path1, string.Join("a", new string[10000]));
                File.AppendAllText(path2, string.Join("a", new string[100000]));
                ar.TryAddNotDuplicate(new ExFileInfo(path1));
                ar.TryAddNotDuplicate(new ExFileInfo(path2));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\3.c"));
                ar.UpdateFileSize(new List<int>(){0, 1});
                msg.Add("2024/06/03 14:14");
                if (ar.ElementAt(0).Size == 0){
                    return msg;
                }
                msg.Add("2024/06/03 14:15");
                if (ar.ElementAt(1).Size == 0){
                    return msg;
                }
                msg.Add("2024/06/03 14:16");
                if (ar.ElementAt(2).Size != 0){
                    return msg;
                }
                File.Delete(path1);
                File.Delete(path2);
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> Test_Filter_TryAdd()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 14:32");
                var ar = new MExFileInfoCollection();
                ar.Filter = (info) => info.FileName().Contains("1");
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\1.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\3.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\2.c"));
                ar.TryAddNotDuplicate(new ExFileInfo(@"c:\test\4.c"));
                msg.Add("2024/06/03 17:43");
                if (ar.Count != 1){
                    return msg;
                }
                msg.Add("2024/06/03 17:44");
                if (ar.ElementAt(0).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                msg.Add("2024/06/03 17:45");
                ar.Filter = (info) => { return true; };
                if (ar.Count != 4){
                    return msg;
                }
                msg.Add("2024/06/03 17:46");
                if (ar.ElementAt(0).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                if (ar.ElementAt(1).FilePath != @"c:\test\3.c"){
                    return msg;
                }
                if (ar.ElementAt(2).FilePath != @"c:\test\2.c"){
                    return msg;
                }
                if (ar.ElementAt(3).FilePath != @"c:\test\4.c"){
                    return msg;
                }
                msg.Add("2024/06/03 17:53");
                ar.Filter = (info) => info.FileName().Contains("1");
                if (ar.Count != 1){
                    return msg;
                }
                if (ar.ElementAt(0).FilePath != @"c:\test\1.c"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
    }
    public class MAliasManagerTest : TestBase
    {
        public override List<string> TestAll()
        {
            return base.TestAll<MAliasManagerTest>();
        }
        public List<string> TestAdd()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 18:26");
                var al = new MAliasManager();
                al.Add("text1", "alias1", false);
                al.Add("text2", "alias2", false);
                al.Add("text3", "alias3", false);
                msg.Add("2024/06/04 09:01");
                if (al.GetAlias("text1") != "alias1"){
                    return msg;
                }
                if (al.GetAlias("text2") != "alias2"){
                    return msg;
                }
                if (al.GetAlias("text3") != "alias3"){
                    return msg;
                }
                msg.Add("2024/06/04 09:04");
                al.Add("text3", "alias3", true);
                if (al.GetAlias("text3") != "alias3"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestRead()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/03 18:26"); // チェックポイント
                var al = new MAliasManager();
                var list = new List<string>()
                {
                    "text1:alias1",
                    "text2:alias2",
                    "text3:alias3"
                };
                Func<List<string>> func = () => list;
                al.Read(func);
                msg.Add("2024/06/04 09:01"); // チェックポイント
                if (al.GetAlias("text1") != "alias1"){
                    return msg;
                }
                if (al.GetAlias("text2") != "alias2"){
                    return msg;
                }
                if (al.GetAlias("text3") != "alias3"){
                    return msg;
                }
                msg.Add("2024/06/04 09:04"); // チェックポイント
                al.Add("text3", "alias3", true);
                if (al.GetAlias("text3") != "alias3"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestRemove()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 09:16");
                var al = new MAliasManager();
                al.Add("text1", "alias1", false);
                al.Add("text2", "alias2", false);
                al.Add("text3", "alias3", false);
                msg.Add("2024/06/04 09:16");
                if (al.GetAlias("text1") != "alias1"){
                    return msg;
                }
                msg.Add("2024/06/04 09:16");
                al.Remove("text1");
                if (al.GetAlias("text1") != string.Empty){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestGetNamesFuzzy()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 09:20"); //チェックポイント
                var al = new MAliasManager();
                al.Add("text1", "alias1", false);
                al.Add("text2", "abcsd", false);
                al.Add("text3", "abbgs", false);
                msg.Add("2024/06/06 22:04");
                var names = al.GetNamesFuzzy("a*");
                if (names.Count != 3){
                    return msg;
                }
                names.Sort();
                msg.Add("2024/06/06 22:05");
                if (names[0] != "text1"){
                    return msg;
                }
                msg.Add("2024/06/06 22:06");
                if (names[1] != "text2"){
                    return msg;
                }
                msg.Add("2024/06/06 22:07");
                if (names[2] != "text3"){
                    return msg;
                }
                names = al.GetNamesFuzzy("ab*");
                names.Sort();
                msg.Add("2024/06/06 22:07-1");
                if (names[0] != "text2"){
                    return msg;
                }
                msg.Add("2024/06/06 22:07-2");
                if (names[1] != "text3"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestSave()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 09:20"); //チェックポイント
                var al = new MAliasManager();
                al.Add("text1", "alias1", false);
                al.Add("text2", "alias2", false);
                al.Add("text3", "alias3", false);
                var path = Path.GetTempFileName();
                Action<List<string>> save = (list) =>
                {
                    using (var writer = new StreamWriter(path))
                    {
                        foreach (var val in list)
                        {
                            writer.WriteLine(val);
                        }
                    }
                };
                msg.Add("2024/06/04 09:23"); //チェックポイント
                al.Save(save);
                msg.Add("2024/06/04 09:24"); //チェックポイント
                al = new MAliasManager();
                Func<List<string>> read = () =>
                {
                    //
                    using (var reader = new StreamReader(path))
                    {
                        var list = new List<string>();
                        while (!reader.EndOfStream)
                        {
                            list.Add(reader.ReadLine());
                        }
                        return list;
                    }
                };
                al.Read(read);
                msg.Add("2024/06/04 09:29"); //チェックポイント
                if (al.GetAlias("text1") != "alias1"){
                    return msg;
                }
                if (al.GetAlias("text2") != "alias2"){
                    return msg;
                }
                if (al.GetAlias("text3") != "alias3"){
                    return msg;
                }
                File.Delete(path);
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
    }
    public class MTagManagerTest : TestBase
    {
        public override List<string> TestAll()
        {
            return base.TestAll<MTagManagerTest>();
        }
        public List<string> TestAdd_GetNames_GetTags()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 09:50"); //チェックポイント
                var ta = new MTagManager();
                ta.Add("test1", "tag1");
                ta.Add("test2", "tag2");
                ta.Add("test3", "tag3");
                ta.Add("test4", "tag3");
                ta.Add("test3", "tag4");
                msg.Add("2024/06/04 10:21"); //チェックポイント
                if (ta.GetTags("test1").Count != 1){
                    return msg;
                }
                if (ta.GetTags("test1")[0] != "tag1"){
                    return msg;
                }
                msg.Add("2024/06/04 10:22"); //チェックポイント
                if (ta.GetNames("tag2").Count != 1){
                    return msg;
                }
                if (ta.GetNames("tag2")[0] != "test2"){
                    return msg;
                }
                msg.Add("2024/06/04 10:23"); //チェックポイント
                if (ta.GetTags("test3").Count != 2){
                    return msg;
                }
                if (ta.GetTags("test3")[0] != "tag3" &
                    ta.GetTags("test3")[0] != "tag4"){
                    return msg;
                }
                if (ta.GetTags("test3")[1] != "tag3" &
                    ta.GetTags("test3")[1] != "tag4"){
                    return msg;
                }
                msg.Add("2024/06/04 10:24"); //チェックポイント
                if (ta.GetNames("tag3").Count != 2){
                    return msg;
                }
                if (ta.GetNames("tag3")[0] != "test3" &
                    ta.GetNames("tag3")[0] != "test4"){
                    return msg;
                }
                if (ta.GetNames("tag3")[1] != "test3" &
                    ta.GetNames("tag3")[1] != "test4"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
        public List<string> TestExists()
        {
            var msg = new List<string>(){GetType().Name,MethodBase.GetCurrentMethod().Name};
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 10:38"); //チェックポイント
                var ta = new MTagManager();
                ta.Add("test1", "tag1");
                ta.Add("test2", "tag2");
                ta.Add("test3", "tag3");
                ta.Add("test4", "tag3");
                ta.Add("test3", "tag4");
                msg.Add("2024/06/04 10:39"); //チェックポイント
                if (!ta.Exists("test1", "tag1")){
                    return msg;
                }
                if (!ta.Exists("test3", "tag3")){
                    return msg;
                }
                if (!ta.Exists("test3", "tag4")){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex){msg[msg.Count - 1] += ":err " + ex.Message;return msg;}
            return new List<string>();
        }
        public List<string> TestRemove()
        {
            var msg = new List<string>(){GetType().Name,MethodBase.GetCurrentMethod().Name};
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 12:47"); //チェックポイント
                var ta = new MTagManager();
                ta.Add("test1", "tag1");
                ta.Add("test2", "tag2");
                ta.Add("test3", "tag3");
                ta.Add("test4", "tag3");
                ta.Add("test3", "tag4");
                msg.Add("2024/06/04 12:48"); //チェックポイント
                ta.Remove("test3", "tag3");
                ta.Remove("test4", "tag3");
                if (ta.Exists("test3", "tag3") | ta.Exists("test4", "tag3")){
                    return msg;
                }
                msg.Add("2024/06/04 12:49"); //チェックポイント
                if (ta.GetTags("test3").Count != 1){
                    return msg;
                }
                msg.Add("2024/06/04 12:50"); //チェックポイント
                if (ta.GetNames("tag3").Count != 0){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex){msg[msg.Count - 1] += ":err " + ex.Message;return msg;}
            return new List<string>();
        }
        public List<string> TestRead()
        {
            var msg = new List<string>(){GetType().Name,MethodBase.GetCurrentMethod().Name};
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 12:51"); //チェックポイント
                var ta = new MTagManager();
                ta.Read(new List<string>()
                {
                    "test1:tag1",
                    "test2:tag2",
                    "test3:tag3,tag4",
                    "test4:tag3",
                });
                msg.Add("2024/06/04 12:54"); //チェックポイント
                if (ta.GetNames("tag1").Count != 1){
                    return msg;
                }
                if (ta.GetNames("tag1")[0] != "test1"){
                    return msg;
                }
                msg.Add("2024/06/04 12:55"); //チェックポイント
                if (ta.GetNames("tag2").Count != 1){
                    return msg;
                }
                if (ta.GetNames("tag2")[0] != "test2"){
                    return msg;
                }
                msg.Add("2024/06/04 12:56"); //チェックポイント
                if (ta.GetNames("tag3").Count != 2){
                    return msg;
                }
                if (ta.GetNames("tag3")[0] != "test3" & ta.GetNames("tag3")[0] != "test4"){
                    return msg;
                }
                if (ta.GetNames("tag3")[1] != "test3" & ta.GetNames("tag3")[1] != "test4"){
                    return msg;
                }
                msg.Add("2024/06/04 12:57"); //チェックポイント
                if (ta.GetNames("tag4").Count != 1){
                    return msg;
                }
                if (ta.GetNames("tag4")[0] != "test3"){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex){msg[msg.Count - 1] += ":err " + ex.Message;return msg;}
            return new List<string>();
        }
        public List<string> TestSave()
        {
            var msg = new List<string>(){GetType().Name,MethodBase.GetCurrentMethod().Name};
            try
            {
                //以下テストコード
                msg.Add("2024/06/04 13:24"); //チェックポイント
                var ta = new MTagManager();
                ta.Add("test1", "tag1");
                ta.Add("test2", "tag2");
                ta.Add("test3", "tag3");
                ta.Add("test3", "tag4");
                ta.Add("test4", "tag3");
                msg.Add("2024/06/04 13:25"); //チェックポイント
                var path = Path.GetTempFileName();
                Action<List<string>> fn = (list) =>
                {
                    using (var writer = new StreamWriter(path))
                    {
                        list.ForEach(val => writer.WriteLine(val));
                    }
                };
                ta.Save(fn);
                msg.Add("2024/06/04 16:46"); //チェックポイント
                using (var reader = new StreamReader(path))
                {
                    var list = new List<string>();
                    while (!reader.EndOfStream)
                    {
                        list.Add(reader.ReadLine());
                    }
                    msg.Add("2024/06/04 16:47"); //チェックポイント
                    if (list.Count != 4){
                        return msg;
                    }
                    msg.Add("2024/06/04 16:48"); //チェックポイント
                    if (list[0] != "test1:tag1"){
                        return msg;
                    }
                    if (list[1] != "test2:tag2"){
                        return msg;
                    }
                    if (list[2] != "test3:tag3,tag4"){
                        return msg;
                    }
                    if (list[3] != "test4:tag3"){
                        return msg;
                    }
                }
                msg.Add("2024/06/04 16:49"); //チェックポイント
                File.Delete(path);
                //以上テストコード
            }
            catch (Exception ex){msg[msg.Count - 1] += ":err " + ex.Message;return msg;}
            return new List<string>();
        }
    }
    public class MyToolTest : TestBase
    {
        public override List<string> TestAll()
        {
            return base.TestAll<MyToolTest>();
        }
        public List<string> TestFuzzyContains()
        {
            var msg = new List<string>();
            msg.Add(GetType().Name);
            msg.Add(System.Reflection.MethodBase.GetCurrentMethod().Name);
            try
            {
                //以下テストコード
                msg.Add("2024/06/06 20:20-1");
                if (!MyTool.FuzzyContains("*th*", "Method")){
                    return msg;
                }
                msg.Add("2024/06/06 20:20-2");
                if (MyTool.FuzzyContains("*tha*", "Method")){
                    return msg;
                }
                msg.Add("2024/06/06 20:20-3");
                if (!MyTool.FuzzyContains("*th*d*", "Method")){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex)
            {
                msg[msg.Count - 1] += ":err " + ex.Message;
                return msg;
            }
            return new List<string>();
        }
    }
// ==========================================================================
// ==========================================================================
// ==========================================================================
// ==========================================================================
// ==========================================================================
    public abstract class TestBase
    {
        // ======================================================================================
        // テストメソッドサンプル
        // ======================================================================================
        public List<string> CodeSample()
        {
            var msg = new List<string>(){GetType().Name,MethodBase.GetCurrentMethod().Name};
            try
            {
                //以下テストコード
                msg.Add("2024/05/31 15:52"); //チェックポイント
                if (DateTime.Now != DateTime.Now){
                    return msg;
                }
                //以上テストコード
            }
            catch (Exception ex){msg[msg.Count - 1] += ":err " + ex.Message;return msg;}
            return new List<string>();
        }
        public abstract List<string> TestAll(); //override するとき <T> に入れるのはに継承先のクラス
        // **************************************************************************************
        // リフレクションでメソッドを列挙する際自分自身のメソッドを除外するのを忘れずに！
        // **************************************************************************************
        protected List<string> TestAll<T>()
        {
            var methods = typeof(T).GetMethods(
                BindingFlags.Public |
                BindingFlags.Instance |
                BindingFlags.DeclaredOnly
            );
            var testMsg = new List<string>();
            foreach (var m in methods)
            {
                if (m.Name == "TestAll"){
                    continue;
                }
                var ins = this;
                var objects = new object[0];
                List<string> methodMsg = (List<string>)m.Invoke(ins,objects);
                for (int i = methodMsg.Count - 4; i >= 0; i--)
                {
                    methodMsg.RemoveAt(2);
                }
                if (methodMsg.Count != 0){
                    testMsg.Add(string.Join(" / ", methodMsg));
                }
            }
            return testMsg;
        }
    }
}
