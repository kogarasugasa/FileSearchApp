using System;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Drawing.Imaging;

namespace IconEx
{
    public static class IconEx
    {
        public static void Main(string[] args)
        {
            string iconPath = Application.StartupPath + @"\AppIcon.ico";
            string bitmapPath = Application.StartupPath + @"\AppIcon.bmp";
            //string bitmapPath = Application.StartupPath + @"\test.bmp";
            var bc = new BitmapCreater();
            var ic = new IconCreater();
            var bc2 = new BitmapCreater2();
            bc2.Create(bitmapPath, 268);
            ic.Create(iconPath, bitmapPath, 32);
            Console.WriteLine("prease enter");
            Console.ReadLine();
        }
    }
    public class BitmapCreater2
    {
        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        private static extern uint ExtractIconEx(string lpszFile, int nIconIndex, IntPtr[] phiconLarge, IntPtr phiconSmall, uint nIcons);
        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        private static extern uint ExtractIconEx(string lpszFile, int nIconIndex, IntPtr phiconLarge, IntPtr phiconSmall, uint nIcons);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        extern static bool DestroyIcon(IntPtr handle);
        public int Create(string bitmapPath, int iconIndex)
        {
            string dllPath = @"c:\Windows\System32\SHELL32.dll";
            uint iconCnt = ExtractIconEx(dllPath, -1, IntPtr.Zero, IntPtr.Zero, 1);
            if (iconCnt == 0)
            {
                return 0;
            }

            IntPtr[] hIcon = new IntPtr[iconCnt];
            try
            {
                // アイコンハンドル＆ハンドル数の取得
                uint getCnt;
                getCnt = ExtractIconEx(dllPath, 0, hIcon, IntPtr.Zero, iconCnt);
                if (getCnt < 1)
                {
                    return 0;   // アイコンがなければ終了
                }
                for (int idx = 0; idx < getCnt; ++idx)
                {
                    if (hIcon[idx] != IntPtr.Zero)
                    {
                        if (idx == iconIndex)
                        {
                            using (Icon icon = Icon.FromHandle(hIcon[idx]))
                            {
                                string filePath = bitmapPath;
                                Bitmap bitmap = icon.ToBitmap();
                                bitmap.Save(filePath);
                                bitmap.Dispose();
                            }
                            break;
                        }
                    }
                }
                return (int)getCnt;
            }
            finally
            {
                foreach (IntPtr ptr in hIcon)
                {
                    if (ptr != IntPtr.Zero)
                        DestroyIcon(ptr);
                }
            }
        }
    }
    public class BitmapCreater
    {
        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        private static extern uint ExtractIconEx(string lpszFile, int nIconIndex, IntPtr[] phiconLarge, IntPtr phiconSmall, uint nIcons);

        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        private static extern uint ExtractIconEx(string lpszFile, int nIconIndex, IntPtr phiconLarge, IntPtr phiconSmall, uint nIcons);
        // SHGetFileInfo関数
        [DllImport("shell32.dll")]
        public static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes, ref SHFILEINFO psfi, uint cbSizeFileInfo, uint uFlags);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        extern static bool DestroyIcon(IntPtr handle);
        // SHGetFileInfo関数で使用するフラグ
        public const uint SHGFI_ICON = 0x100; // アイコン・リソースの取得
        public const uint SHGFI_LARGEICON = 0x0; // 大きいアイコン
        public const uint SHGFI_SMALLICON = 0x1; // 小さいアイコン
        public void Create(string pFilePath)
        {
            // アプリケーション・アイコンを取得
            SHFILEINFO shinfo = new SHFILEINFO();
            IntPtr hSuccess = SHGetFileInfo(@"C:\WINDOWS\system32\notepad.exe", 0, ref shinfo, (uint)Marshal.SizeOf(shinfo), SHGFI_ICON | SHGFI_LARGEICON);
            if (hSuccess == IntPtr.Zero)
            {
                throw new Exception("アイコンの取得に失敗しました");
            }
            try
            {
                Icon appIcon = null;
                using (appIcon = Icon.FromHandle(shinfo.hIcon))
                using (var bitmap = appIcon.ToBitmap())
                {
                    bitmap.Save(pFilePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
    public class IconCreater
    {
        public void Create(string iconFilePath, string bitmapFilePath)
        {
            Image img = Image.FromFile(bitmapFilePath);

            // アイコンの大きさは32×32
            Bitmap bitmap = new Bitmap(32, 32, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            Graphics g = Graphics.FromImage(bitmap);
            g.DrawImage(img, new Rectangle(0, 0, 32, 32));
            g.Dispose();

            //ビットマップをアイコンへ変換
            Icon icon = Icon.FromHandle(bitmap.GetHicon());
            Stream outStream = new FileStream(iconFilePath, FileMode.Create, FileAccess.Write);
            icon.Save(outStream);

            //後始末
            outStream.Close();
            bitmap.Dispose();
            icon.Dispose();
            img.Dispose();
        }
        public void Create(string iconPath, string bitmapPath, int size)
        {
            var img = Image.FromFile(bitmapPath);
            {
                Icon icon;
                using (var msImg = new MemoryStream())
                using (var msIco = new MemoryStream())
                {
                    img.Save(msImg, ImageFormat.Png);
                    using (var bw = new BinaryWriter(msIco))
                    {
                        bw.Write((short)0);           //0-1 reserved
                        bw.Write((short)1);           //2-3 image type, 1 = icon, 2 = cursor
                        bw.Write((short)1);           //4-5 number of images
                        bw.Write((byte)size);         //6 image width
                        bw.Write((byte)size);         //7 image height
                        bw.Write((byte)0);            //8 number of colors
                        bw.Write((byte)0);            //9 reserved
                        bw.Write((short)0);           //10-11 color planes
                        bw.Write((short)32);          //12-13 bits per pixel
                        bw.Write((int)msImg.Length);  //14-17 size of image data
                        bw.Write(22);                 //18-21 offset of image data
                        bw.Write(msImg.ToArray());    // write image data
                        bw.Flush();
                        bw.Seek(0, SeekOrigin.Begin);
                        icon = new Icon(msIco);
                    }
                }
                using (var fs = new FileStream(iconPath, FileMode.Create, FileAccess.Write))
                {
                    icon.Save(fs);
                }
            }
        }
    }
    public struct SHFILEINFO // SHGetFileInfo関数で使用する構造体
    {
        public IntPtr hIcon;
        public IntPtr iIcon;
        public uint dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string szTypeName;
    }
}